/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

define([
    'jquery',
    'mage/translate',
    'jquery/ui',
    'mage/validation/validation'
], function ($, $t) {
    'use strict';

    $.widget('tigren.ajaxToGroup', {
        options: {
            processStart: null,
            processStop: null,
            isEnable: null,
            miniCartElement: null,
            addToGroupButton: null,
            popupForm: null,
            optionsPopup: null,
            addToWishlistGroup: null,
            initConfig: {
                'show_success_message': true,
                'timeErrorMessage': 3000,
                'addWishlistItemUrl': null,
            },
            closePopupButtonSelector: 'button#ajaxgroup_cancel',
            closePopupStickerSelector: 'button#ajaxgroup_cancel2',
            addToGroupButtonSelector: '[data-action="add-to-wishlist"]',
            buttonSendEmailSelector: 'button#mb-send-email',
            sendEmailToFriend: 'button#mb-send-email-popup',
            popupTTL: 10,
            sendEmailToFriendUrl: null,
            sendEmailToFriendAction: null,
            buttonChangeGroup: 'a#mb-ajax-a-change-group',
            buttonGroupSelector: 'button#ajaxgroup_change',
            formKey: null,
            formKeyInputSelector: 'input[name="form_key"]'
        },

        _create: function () {
            this._bindSubmit();
            this.options.formKey = $(this.options.formKeyInputSelector).val();
        },

        _bindSubmit: function () {
            var self = this;
            this.createElements();

            $(self.options.addToGroupButtonSelector).on('click', function (e) {
                if ($('body').hasClass('wishlist-index-configure')) {
                    e.preventDefault();
                    var form = $(this).closest('form');
                    return;
                }

                e.preventDefault();
                e.stopPropagation();
                var dataPost = $(this).data('post');
                dataPost.data.form_key = self.options.formKey;
                self.showPopup(dataPost.data, dataPost.action);
            });

            $(self.options.buttonSendEmailSelector).on('click', function (e) {
                self.showPopupEmail({}, self.options.sendEmailToFriendUrl);
            });

            $(self.options.buttonChangeGroup).on('click', function (e) {
                e.preventDefault();
                var dataPost = $(this).data('post-change-group');
                dataPost.data["groupIdOld"] = $("input[name=group-id]").val();
                self.showPopupChangeGroup(dataPost.data, self.options.ajaxUpdateGroup);
            });
        },

        createElements: function () {
            if (!($('#ajaxgroup_content_option_product').length)) {
                $(document.body).append('<div class="block" id="ajaxgroup_content_option_product"></div>');
            }
            this.options.optionsPopup = $('#ajaxgroup_content_option_product');
            this.options.optionsPopup.hide();
        },

        isLoaderEnabled: function () {
            return this.options.processStart && this.options.processStop;
        },

        showPopupChangeGroup: function (params, actionUrl) {
            var self = this;

            params.isPopupChangeGroup = true;
            $.ajax({
                url: actionUrl,
                data: params,
                type: 'post',
                dataType: 'json',
                beforeSend: function () {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStart);
                    }
                },
                success: function (res) {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStop);
                    }
                    if (res.html_popup) {
                        self.options.optionsPopup.html(res.html_popup);
                        self.options.optionsPopup.show();
                    }

                    $(self.options.buttonGroupSelector).click(function (event) {
                        var groupIdNew = $("#mb-select-group").val();
                        var groupIdOld = $("input[name=group-id]").val();
                        var obj = {
                            "groupIdOld": groupIdOld,
                            "groupIdNew" : groupIdNew,
                            "itemId" : res.item
                        }
                        self.changeGroup(obj, self.options.ajaxUpdateGroup);
                    });

                    $(self.options.closePopupButtonSelector).click(function (event) {
                        self.closePopup();
                    });
                }
            });
        },

        changeGroup: function (params, actionUrl) {
            var self = this;

            params.isChangeGroup = true;
            $.ajax({
                url: actionUrl,
                data: params,
                type: 'post',
                dataType: 'json',
                beforeSend: function () {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStart);
                    }
                },
                success: function (res) {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStop);
                    }
                    if (res.html_popup) {
                        self.options.optionsPopup.html(res.html_popup);
                        self.options.optionsPopup.show();
                    }

                    $(self.options.closePopupButtonSelector).click(function (event) {
                        self.closePopup();
                    });
                }


            });
        },

        showPopupEmail: function (params, actionUrl) {
            var self = this;

            params.isEmail = true;
            $.ajax({
                url: actionUrl,
                data: params,
                type: 'post',
                dataType: 'json',
                beforeSend: function () {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStart);
                    }
                },
                success: function (res) {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStop);
                    }
                    if (res.html_popup) {
                        self.options.optionsPopup.html(res.html_popup);
                        self.options.optionsPopup.show();
                    }

                    self.options.poupForm = self.options.optionsPopup.find('form#mb-invite-friends-form');

                    if (self.options.poupForm) {
                        self.options.poupForm.mage('validation', {
                            submitHandler: function (form) {
                                self.sendEmail($(form).serialize(), self.options.sendEmailToFriendAction);
                                return false;
                            }
                        });
                    }

                    $(self.options.closePopupButtonSelector).click(function (event) {
                        self.closePopup();
                    });
                }
            });
        },

        sendEmail: function (params, actionUrl) {
            var self = this;

            params.isSendmail = true;
            $.ajax({
                url: actionUrl,
                data: params,
                type: 'post',
                dataType: 'json',
                beforeSend: function () {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStart);
                    }
                },
                success: function (res) {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStop);
                    }
                    if (res.html_popup) {
                        self.options.optionsPopup.html(res.html_popup);
                        self.options.optionsPopup.show();
                    }
                }
            });
        },

        showPopup: function (params, actionUrl) {
            var self = this;

            params.isAjax = true;
            $.ajax({
                url: actionUrl,
                data: params,
                type: 'post',
                dataType: 'json',
                beforeSend: function () {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStart);
                    }
                },
                success: function (res) {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStop);
                    }

                    if (res.html_popup) {
                        self.options.optionsPopup.html(res.html_popup);
                        self.options.optionsPopup.show();

                        self.options.poupForm = self.options.optionsPopup.find('form#product_addtocart_form');

                        if (self.options.poupForm) {
                            self.options.poupForm.mage('validation', {
                                radioCheckboxClosest: '.nested',
                                submitHandler: function (form) {
                                    self.addtoWishlistGroup($(form));
                                    return false;
                                }
                            });
                        }

                        $(self.options.closePopupButtonSelector).click(function (event) {
                            self.closePopup();
                        });

                        $(self.options.closePopupStickerSelector).click(function (event) {
                            self.closePopup();
                        })
                    }

                    if (res.backUrl) {
                        window.location = res.backUrl;
                        return;
                    }
                }
            });
        },

        addtoWishlistGroup: function (form) {
            var self = this,
                params = form.serialize();

            params += '&isPopupSubmit=true';

            $.ajax({
                url: form.attr('action'),
                data: params,
                type: 'post',
                dataType: 'json',
                beforeSend: function () {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStart);
                    }
                },
                success: function (res) {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStop);
                    }

                    if (res.html_popup) {
                        self.options.optionsPopup.html(res.html_popup);
                        self.options.optionsPopup.show();

                        if (self.options.popupTTL) {
                            setTimeout(function () {
                                self.options.optionsPopup.fadeOut('fast').empty();
                            }, self.options.popupTTL * 1000);
                        }

                        self.options.poupForm = self.options.optionsPopup.find('form#product_addtocart_form');

                        if (self.options.poupForm) {
                            self.options.poupForm.mage('validation', {
                                radioCheckboxClosest: '.nested',
                                submitHandler: function (form) {
                                    self.addtoWishlistGroup($(form));
                                    return false;
                                }
                            });
                        }

                        $(self.options.closePopupButtonSelector).click(function (event) {
                            self.closePopup();
                        });

                        $(self.options.closePopupStickerSelector).click(function (event) {
                            self.closePopup();
                        })
                    }
                }
            });

        },
        closePopup: function () {
            this.options.optionsPopup.empty().hide();
        }

    });

    return $.tigren.ajaxToGroup;
});