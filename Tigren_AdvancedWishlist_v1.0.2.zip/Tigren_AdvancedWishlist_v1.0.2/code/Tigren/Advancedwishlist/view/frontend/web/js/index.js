define([
    'jquery',
    'Magento_Ui/js/modal/alert',
    'mage/template',
    'text!SITC_Personalization/template/grid/cells/image/preview.html',
    'Magento_Ui/js/modal/modal',
    'mage/translate'
], function ($, alert, mageTemplate, thumbnailPreviewTemplate) {
    'use strict';
    $.widget('mage.perActionEdit', {
        options: {
            buttonAddNewGroup : '.addgr',
        },
        _create: function () {
            this._bind();
        },
        _bind: function () {
            var self = this;
            $(this.options.buttonAddNewGroup).on('click',function () {
            })
        },
    });
    return $.mage.perActionEdit;
});