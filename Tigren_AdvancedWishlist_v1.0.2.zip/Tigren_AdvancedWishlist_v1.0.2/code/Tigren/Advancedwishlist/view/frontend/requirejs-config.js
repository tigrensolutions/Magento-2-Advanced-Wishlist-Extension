var config = {
    map: {
        '*': {
            'tigren/swatchRenderer':    	'Tigren_WishlistPlus/js/swatch-renderer',
            'tigren/ajaxToGroup':    	    'Tigren_WishlistPlus/js/ajax-to-group'
        }
    }
};

