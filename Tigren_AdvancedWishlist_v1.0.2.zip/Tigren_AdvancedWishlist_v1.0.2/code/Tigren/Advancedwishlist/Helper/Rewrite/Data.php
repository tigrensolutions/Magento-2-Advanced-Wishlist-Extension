<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Helper\Rewrite;

use Magento\Wishlist\Controller\WishlistProviderInterface;
use Magento\Framework\App\ActionInterface;

class Data extends \Magento\Wishlist\Helper\Data
{
    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * Data constructor.
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Wishlist\Model\WishlistFactory $wishlistFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Data\Helper\PostHelper $postDataHelper
     * @param \Magento\Customer\Helper\View $customerViewHelper
     * @param WishlistProviderInterface $wishlistProvider
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Tigren\WishlistPlus\Helper\Data $wishlistHelper
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Wishlist\Model\WishlistFactory $wishlistFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Data\Helper\PostHelper $postDataHelper,
        \Magento\Customer\Helper\View $customerViewHelper,
        WishlistProviderInterface $wishlistProvider,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper)
    {
        parent::__construct($context, $coreRegistry, $customerSession, $wishlistFactory, $storeManager, $postDataHelper, $customerViewHelper, $wishlistProvider, $productRepository);
        $this->_wishlistHelper = $wishlistHelper;
    }

    /**
     * Retrieve URL for configuring item from wishlist
     *
     * @param \Magento\Catalog\Model\Product|\Magento\Wishlist\Model\Item $item
     * @return string
     */
    public function getConfigureUrl($item)
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            if (!empty($this->_request->getParam('group'))) {
                return $this->_getUrl(
                    'wishlist/index/configure',
                    [
                        'id' => $item->getWishlistItemId(),
                        'product_id' => $item->getProductId(),
                        'groupId' => $this->_request->getParam('group')
                    ]
                );
            } else {
                return $this->_getUrl(
                    'wishlist/index/configure',
                    [
                        'id' => $item->getWishlistItemId(),
                        'product_id' => $item->getProductId()
                    ]
                );
            }
        }else{
            return $this->_getUrl(
                'wishlist/index/configure',
                [
                    'id' => $item->getWishlistItemId(),
                    'product_id' => $item->getProductId()
                ]
            );
        }
    }

    /**
     * Retrieve params for removing item from wishlist
     *
     * @param \Magento\Catalog\Model\Product|\Magento\Wishlist\Model\Item $item
     * @param bool $addReferer
     * @return string
     */
    public function getRemoveParams($item, $addReferer = false)
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            $url = $this->_getUrl('wishlist/index/remove');
            $params = [
                'item' => $item->getWishlistItemId(),
                'qty' => $item->getQty(),
                'groupId' => $this->_request->getParam('group')
            ];

            if ($addReferer) {
                $params = $this->addRefererToParams($params);
            }

            return $this->_postDataHelper->getPostData($url, $params);
        }else{
            $url = $this->_getUrl('wishlist/index/remove');
            $params = ['item' => $item->getWishlistItemId()];
            $params[ActionInterface::PARAM_NAME_URL_ENCODED] = '';

            if ($addReferer) {
                $params = $this->addRefererToParams($params);
            }

            return $this->_postDataHelper->getPostData($url, $params);
        }
    }

    /**
     * Retrieve params for updating product in wishlist
     *
     * @param \Magento\Catalog\Model\Product|\Magento\Wishlist\Model\Item $item
     *
     * @return  string|false
     */
    public function getUpdateParams($item)
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            $itemId = null;
            if ($item instanceof \Magento\Catalog\Model\Product) {
                $itemId = $item->getWishlistItemId();
                $productId = $item->getId();
            }
            if ($item instanceof \Magento\Wishlist\Model\Item) {
                $itemId = $item->getId();
                $productId = $item->getProduct()->getId();
            }

            $url = $this->_getUrl('wishlist/index/updateItemOptions');
            if ($itemId && $this->_request->getParam('groupId')) {
                $params = [
                    'id' => $itemId,
                    'product' => $productId,
                    'groupId' => $this->_request->getParam('groupId'),
                    'qty' => $item->getQtyInGroup($this->_request->getParam('groupId'))
                ];
                return $this->_postDataHelper->getPostData($url, $params);
            } else {
                if ($itemId) {
                    $params = ['id' => $itemId, 'product' => $productId, 'qty' => $item->getQty()];
                    return $this->_postDataHelper->getPostData($url, $params);
                }

            }

            return false;
        }else{
            $itemId = null;
            if ($item instanceof \Magento\Catalog\Model\Product) {
                $itemId = $item->getWishlistItemId();
                $productId = $item->getId();
            }
            if ($item instanceof \Magento\Wishlist\Model\Item) {
                $itemId = $item->getId();
                $productId = $item->getProduct()->getId();
            }

            $url = $this->_getUrl('wishlist/index/updateItemOptions');
            if ($itemId) {
                $params = ['id' => $itemId, 'product' => $productId, 'qty' => $item->getQty()];
                return $this->_postDataHelper->getPostData($url, $params);
            }
            return false;
        }
    }
}
