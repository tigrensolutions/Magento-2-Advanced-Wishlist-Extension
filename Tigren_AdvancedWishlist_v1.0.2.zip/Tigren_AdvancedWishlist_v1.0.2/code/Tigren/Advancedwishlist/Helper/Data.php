<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Helper;

use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\View\LayoutFactory;

/**
 * Catalog data helper
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Currently selected store ID if applicable
     *
     * @var int
     */
    protected $_storeId;

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var CustomerSession
     */
    protected $_customerSession;

    /**
     * @var \Magento\Framework\View\Result\LayoutFactory
     */
    protected $_layoutFactory;

    /**
     * @var \Magento\Framework\Json\EncoderInterface
     */
    protected $_jsonEncoder;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Registry $coreRegistry
     * @param CustomerSession $customerSession
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Registry $coreRegistry,
        CustomerSession $customerSession,
        LayoutFactory $layoutFactory,
        EncoderInterface $jsonEncoder
    ){
        $this->_storeManager = $storeManager;
        $this->_coreRegistry = $coreRegistry;
        $this->_customerSession = $customerSession;
        $this->_layoutFactory = $layoutFactory;
        $this->_jsonEncoder = $jsonEncoder;
        parent::__construct($context);
    }

    /**
     * Set a specified store ID value
     *
     * @param int $store
     * @return $this
     */
    public function setStoreId($store)
    {
        $this->_storeId = $store;
        return $this;
    }

    /**
     * @param $product
     * @return string
     */
    public function getOptionsPopupHtml($product)
    {
        $layout = $this->_layoutFactory->create();

        $update = $layout->getUpdate();
        $update->load('wlplus_options_popup');

        $layout->generateXml();
        $layout->generateElements();

        return $layout->getOutput();
    }

    /**
     * @param $product
     * @return string
     */
    public function getSuccessHtml($product)
    {
        $layout = $this->_layoutFactory->create();
        $layout->getUpdate()->load('wlplus_success_message');
        $layout->generateXml();
        $layout->generateElements();

        return $layout->getOutput();
    }

    /**
     * @return string
     */
    public function getEmailHtml()
    {
        $layout = $this->_layoutFactory->create();
        $layout->getUpdate()->load('wlplus_success_email');
        $layout->generateXml();
        $layout->generateElements();

        return $layout->getOutput();
    }

    /**
     * @return string
     */
    public function getChangeGroupHtml()
    {
        $layout = $this->_layoutFactory->create();
        $layout->getUpdate()->load('wlplus_success_load_group');
        $layout->generateXml();
        $layout->generateElements();

        return $layout->getOutput();
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getMessageSuccessChangeGroupHtml()
    {
        $layout = $this->_layoutFactory->create();
        $layout->getUpdate()->load('wlplus_success_change_group');
        $layout->generateXml();
        $layout->generateElements();

        return $layout->getOutput();
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getMessageErrorChangeGroupHtml()
    {
        $layout = $this->_layoutFactory->create();
        $layout->getUpdate()->load('wlplus_error_change_group');
        $layout->generateXml();
        $layout->generateElements();

        return $layout->getOutput();
    }

    /**
     * @param $product
     * @return string
     */
    public function getErrorHtml($product)
    {
        $layout = $this->_layoutFactory->create();
        $layout->getUpdate()->load('wlplus_error_message');
        $layout->generateXml();
        $layout->generateElements();

        return $layout->getOutput();
    }

    /**
     * @return bool
     */
    public function isEnabledWishlistPlus()
    {
        return (bool)$this->scopeConfig->getValue(
            'wishlistplus/general/enabled',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->_storeId
        );
    }

    /**
     * Check login
     *
     * @return int
     */
    public function checkLogin()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');

        if ($customerSession->isLoggedIn()) {
            return 1;
        }
        return 0;
    }

    /**
     * @param int $isPopup
     * @return string
     */
    public function getAjaxGroupInitOptions($isPopup = 0)
    {
        $options = [
            'isPopup' => $isPopup,
            'isEnable' => $this->isWishlistPlusEnable(),
            'processStart' => 'processStart',
            'processStop' => 'processStop',
            'addToGroupUrl' => $this->_urlBuilder->getUrl('wlplus/group/showPopup'),
            'addToWishlistGroup' => $this->_urlBuilder->getUrl('wishlist/index/add'),
            'addToPluginAdd' => $this->_urlBuilder->getUrl('wishlist/index/add'),
            'sendEmailToFriendUrl' => $this->_urlBuilder->getUrl('wlplus/group/email'),
            'ajaxUpdateGroup' => $this->_urlBuilder->getUrl('wlplus/group/update'),
            'sendEmailToFriendAction' => $this->_urlBuilder->getUrl('wlplus/group/sendmail'),
            'popupTTL' => $this->getPopupTTL()
        ];

        return $this->_jsonEncoder->encode($options);
    }

    /**
     * @return bool
     */
    public function isWishlistPlusEnable()
    {
        return (bool)$this->scopeConfig->getValue(
            'wishlistplus/general/enable',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->_storeId
        );
    }

    /**
     *
     *
     * @return int
     */
    public function getPopupTTL()
    {
        if ($this->isEnabledPopupTTL()) {
            return (int)$this->scopeConfig->getValue(
                'wishlistplus/general/popupttl',
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $this->_storeId
            );
        }
        return 0;
    }

    /**
     * @return bool
     */
    public function isEnabledPopupTTL()
    {
        return (bool)$this->scopeConfig->getValue(
            'wishlistplus/general/enabled_popupttl',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->_storeId
        );
    }
}
