<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block\Adminhtml\Edit\Tab\View\Grid\Renderer;

/**
 * Adminhtml customers wishlist grid item renderer for name/options cell
 */
class Item extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Tigren\WishlistPlus\Model\GroupFactory
     */
    protected $_groupFactory;

    /**
     * Item constructor.
     * @param \Magento\Backend\Block\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Tigren\WishlistPlus\Model\GroupFactory $groupFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Tigren\WishlistPlus\Model\GroupFactory $groupFactory,
        array $data = []
    ) {
        $this->_groupFactory = $groupFactory;
        parent::__construct($context, $data);
        $this->_storeManager = $storeManager;
    }

    /**
     * Get group name
     *
     * @param \Magento\Framework\DataObject $row
     * @return mixed
     */
    public function render(\Magento\Framework\DataObject $row)
    {
        $model = $this->_groupFactory->create();
        $groupIds = $model->getGroupByWishlistItemId($row->getId());


        $groupName = '';
        foreach ($groupIds as $groupId) {

            $groupName .= '* ' . $model->load($groupId)->getGroupName() . '<br>';
        }

        return $groupName;

    }

}
