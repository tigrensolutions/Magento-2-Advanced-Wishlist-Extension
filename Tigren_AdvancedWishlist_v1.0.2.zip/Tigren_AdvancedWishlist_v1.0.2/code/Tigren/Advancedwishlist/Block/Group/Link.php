<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block\Group;

class Link extends \Magento\Framework\View\Element\Html\Link
{
    /**
     * @var \Magento\Customer\Model\Url
     */
    protected $_groupUrl;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Customer\Model\Url $customerUrl
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Tigren\WishlistPlus\Model\Url $groupUrl,
        array $data = []
    ) {
        $this->_groupUrl = $groupUrl;
        parent::__construct($context, $data);
    }

    /**
     * Create link for wishlistplus group
     *
     * @return string
     */
    public function getHref()
    {
        return $this->_groupUrl->getGroupUrl();
    }
}
