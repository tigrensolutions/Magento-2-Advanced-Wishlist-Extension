<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block\Group;

use Magento\Framework\View\Element\Template;

class Add extends Template
{
    /**
     * Get url action Save
     * @return string
     */
    public function getFormAction()
    {
        return $this->_urlBuilder->getUrl('wlplus/group/save');
    }
}