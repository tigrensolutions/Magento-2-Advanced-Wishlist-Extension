<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block\Group;

use Magento\Catalog\Model\ProductRepository;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Tigren\WishlistPlus\Model\GroupFactory;
use Tigren\WishlistPlus\Model\ResourceModel\Reminder\Collection;
use Tigren\WishlistPlus\Model\ResourceModel\Reminder\CollectionFactory;

/**
 * Class Index
 * @package Tigren\WishlistPlus\Block\Group
 */
class Index extends \Magento\Wishlist\Block\AbstractBlock
{
    /**
     * @var GroupFactory
     */
    protected $_groupFactory;

    /**
     * @var \Magento\Framework\Data\Helper\PostHelper
     */
    protected $postDataHelper;

    /**
     * @var Session
     */
    protected $_customerSession;

    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * Currently selected store ID if applicable
     *
     * @var int
     */
    protected $_storeId;

    /**
     * @var ProductRepository
     */
    protected $_productRepository;

    /**
     * @var Tigren\WishlistPlus\Model\ReminderFactory
     */
    protected $_reminderCollectionFactory;

    protected $_reminderCollection;

    /**
     * Index constructor.
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param \Magento\Framework\App\Http\Context $httpContext
     * @param GroupFactory $groupFactory
     * @param \Magento\Framework\Data\Helper\PostHelper $postDataHelper
     * @param Session $session
     * @param array $data
     */
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Magento\Framework\App\Http\Context $httpContext,
        GroupFactory $groupFactory,
        \Magento\Framework\Data\Helper\PostHelper $postDataHelper,
        \Magento\Customer\Model\Session $session,
        array $data,
        ScopeConfigInterface $scopeConfig,
        ProductRepository $productRepository,
        CollectionFactory $reminderCollectionFactory,
        Collection $reminderCollection
    ) {
        $this->_productRepository = $productRepository;
        $this->_scopeConfig = $scopeConfig;
        $this->_customerSession = $session;
        $this->postDataHelper = $postDataHelper;
        $this->_groupFactory = $groupFactory;
        $this->_reminderCollectionFactory = $reminderCollectionFactory;
        $this->_reminderCollection = $reminderCollection;
        parent::__construct($context, $httpContext, $data);
    }

    /**
     * Set a specified store ID value
     *
     * @param int $store
     * @return $this
     */
    public function setStoreId($store)
    {
        $this->_storeId = $store;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getDefaultGroupConfig()
    {
        return $this->_scopeConfig
            ->getValue('wishlistplus/display/group', ScopeInterface::SCOPE_STORE, $this->_storeId);
    }

    /**
     * get Id product in wishlist
     *
     * @return string
     */
    public function getAddAllToCartParams()
    {
        return $this->postDataHelper->getPostData(
            $this->getUrl('wishlist/index/allcart'),
            ['wishlist_id' => $this->getWishlistInstance()->getId()]
        );
    }

    /**
     * Get Group link for table
     *
     * @return string
     */
    public function getGroupLink()
    {
        return $this->getUrl('wlplus/group/index');
    }

    /**
     * Get url sendmail action
     *
     * @return string
     */
    public function getSendMaillLink()
    {
        return $this->getUrl('wlplus/group/sendmail');
    }

    /**
     * Get Group name for popup
     *
     * @return mixed
     */
    public function getGroupName()
    {
        $params = $this->getRequest()->getParams();
        if (!empty($params['mb-select-group'])) {
            $groupId = $params['mb-select-group'];
            $model = $this->_groupFactory->create()->load($groupId);
            return $model->getGroupName();
        }
        return;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getMessageForSuccessChangeGroup()
    {
        $groupId = $this->_coreRegistry->registry('groupIdNew');
        $itemId = $this->_coreRegistry->registry('itemId');
        $groupName = $this->_groupFactory->create()->load($groupId)->getGroupName();
        $productName = $this->_productRepository->getById($itemId)->getName();
        $data = ['groupName' => $groupName, 'productName' => $productName];

        return $data;

    }

    /**
     * Get link window.location for popup
     *
     * @return string
     */
    public function getGroupViewUrl()
    {
        $params = $this->getRequest()->getParams();
        if (!empty($params['mb-select-group'])) {
            $groupId = $params['mb-select-group'];
            return $this->getUrl('wlplus/group/view', ['group' => $groupId]);
        }
        return;

    }

    /**
     * Filter Group for ajax change group
     *
     * @return $this
     */
    public function getGroupsFilter()
    {
        $customerId = $this->_customerSession->getCustomer()->getId();
        $groupId = $this->_request->getParam('groupIdOld');

        $groupFactoryCollection = $this->_groupFactory->create()->getCollection()
            ->addFieldToFilter('tigren_wishlistplus_group_id', ['neq' => $groupId])
            ->addFieldToFilter('customer_id', $customerId);

        return $groupFactoryCollection;
    }

    /**
     * Get group for table
     *
     * @return \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
     */
    public function getGroups()
    {
        $customerId = $this->_customerSession->getCustomer()->getId();
        $model = $this->_groupFactory->create();
        $isCreatedGroup = $model->isCreatedWishlistGroup($customerId);

        if (!$isCreatedGroup) {
            try {
                $model->setCustomerId($customerId)
                    ->setGroupName($this->getDefaultGroupNameConfig())
                    ->setDescription($this->getDefaultDescriptionConfig())
                    ->setSortOrder('ffffff')
                    ->save();

                $model->getItemsForDefaultGroup($customerId);
            } catch (\Exception $e) {
                $this->_logger->debug('Can not get product into group', ['message' => $e->getMessage()]);
            }
        }

        $collection = $this->_groupFactory->create()->getCollection()->addFieldToFilter('customer_id', $customerId);
        return $collection;
    }

    /**
     * @return mixed
     */
    public function getDefaultGroupNameConfig()
    {
        return $this->_scopeConfig
            ->getValue('wishlistplus/display/group_name', ScopeInterface::SCOPE_STORE, $this->_storeId);
    }

    /**
     * @return mixed
     */
    public function getDefaultDescriptionConfig()
    {
        return $this->_scopeConfig
            ->getValue('wishlistplus/display/group_description', ScopeInterface::SCOPE_STORE, $this->_storeId);
    }

    /**
     * @return string
     */
    public function getNewGroupUrlAfterChangeGroup()
    {
        $value = $this->_coreRegistry->registry('groupIdNew');
        return $this->getUrl('wlplus/group/view', ['group' => $value]);
    }

    /**
     * Get link view for View Controller
     *
     * @param $group
     * @return string
     */
    public function getViewUrl($group)
    {
        return $this->getUrl('wlplus/group/view', ['group' => $group['tigren_wishlistplus_group_id']]);
    }

    /**
     * Create link to link Add Controller
     *
     * @return string
     */
    public function getNewGroupUrl()
    {
        return $this->_urlBuilder->getUrl('wlplus/group/add');
    }

    /**
     * @return string
     */
    public function getSaveConfigUrl()
    {
        return $this->_urlBuilder->getUrl('wlplus/group/saveConfig');
    }

    /**
     * @param $group
     * @return string
     */
    public function getDeleteGroupUrl($group)
    {
        return $this->_urlBuilder->getUrl('wlplus/group/delete', ['id' => $group->getTigrenWishlistPlusGroupId()]);
    }

    /*
     * Delete group
     */

    /**
     * Action for form - multidelete
     *
     * @return string
     */
    public function getDeleteSelectedGroupUrl()
    {
        return $this->_urlBuilder->getUrl('wlplus/group/deleteselected');
    }

    /**
     * Format date
     *
     * @param $dateString
     * @return string
     */
    public function _formatDate($dateString)
    {
        $date = new \DateTime($dateString);
        if ($date == new \DateTime('today')) {
            return $this->_localeDate->formatDateTime(
                $date,
                \IntlDateFormatter::NONE,
                \IntlDateFormatter::SHORT
            );
        }
        return $this->_localeDate->formatDateTime(
            $date,
            \IntlDateFormatter::MEDIUM,
            \IntlDateFormatter::MEDIUM
        );
    }

    /**
     *
     */
    public function getReminder()
    {
        $customerId = $this->_customerSession->getCustomer()->getId();
        $connection = $this->_reminderCollection->getConnection();
        $select = $connection->select();
        $select->from(
            ['source_table' => $this->_reminderCollection->getTable('mb_wishlistplus_reminder')],
            ['interval', 'reminder_option', 'count_number', 'reminder']
        )->where(
            'customer_id = ?', $customerId
        )->limit(
            1
        )->order(
            'mb_wishlistplus_reminder_id DESC'
        );
        $reminder = $connection->fetchAll($select);
        return $reminder;
    }

    /**
     * Set title for page
     */
    protected function _construct()
    {
        parent::_construct();
        $this->pageConfig->getTitle()->set(__('Manager Group'));
    }
}