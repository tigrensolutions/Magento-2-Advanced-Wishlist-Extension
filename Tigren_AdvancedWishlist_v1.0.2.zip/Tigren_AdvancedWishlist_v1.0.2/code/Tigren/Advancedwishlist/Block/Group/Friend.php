<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block\Group;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\View\Element\Template;
use Tigren\WishlistPlus\Model\GroupFactory;

class Friend extends Template
{
    /**
     * @var GroupFactory
     */
    protected $_groupFactory;

    /**
     * @var RequestInterface
     */
    protected $_request;

    /**
     * Friend constructor.
     * @param Template\Context $context
     * @param RequestInterface $request
     * @param GroupFactory $groupFactory
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        RequestInterface $request,
        GroupFactory $groupFactory,
        array $data
    ) {
        $this->_request = $request;
        $this->_groupFactory = $groupFactory;
        parent::__construct($context, $data);
    }

    /**
     * Get group name
     *
     * @return mixed
     */
    public function getGroupName()
    {
        $groupId = $this->_request->getParam('group');
        $groupModel = $this->_groupFactory->create()->load($groupId);
        return $groupModel->getGroupName();
    }

    /**
     * Get url action Update
     *
     * @return string
     */
    public function getUpdateLink()
    {
        return $this->_urlBuilder->getUrl('wlplus/group/update');
    }

    /**
     * Get Group Id
     *
     * @return array
     */
    public function getGroupId()
    {
        return $this->_request->getParams('group');
    }
}