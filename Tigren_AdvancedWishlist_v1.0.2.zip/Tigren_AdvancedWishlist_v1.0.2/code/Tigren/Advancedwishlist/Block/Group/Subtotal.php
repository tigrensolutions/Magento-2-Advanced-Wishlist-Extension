<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block\Group;

use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\View\Element\Template;
use Tigren\WishlistPlus\Model\GroupFactory;

class Subtotal extends Template
{
    /**
     * @var GroupFactory
     */
    protected $_groupFactory;

    protected $_productRepository;

    protected $_storeManager;

    protected $_currency;

    public function __construct(
        Template\Context $context,
        GroupFactory $groupFactory,
        ProductRepository $productRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\Currency $currency,
        array $data
    ) {
        $this->_storeManager = $storeManager;
        $this->_currency = $currency;
        $this->_productRepository = $productRepository;
        $this->_groupFactory = $groupFactory;
        parent::__construct($context, $data);
    }

    public function getSubTotal()
    {
        $groupId =   $params = $this->_request->getParams();
        $productIds = $this->getProductInGroup($groupId);
        $total = 0;
        foreach ($productIds as $productId => $qty) {
            $product = $this->_productRepository->getById($productId);
            $total += $product->getFinalPrice() * $qty;
        }
        $value = $this->getCurrentCurrencySymbol() . $total;

        return $value;
    }

    public function getProductInGroup($groupId)
    {
        /**
         * Create Group Model
         */
        $model = $this->_groupFactory->create();
        $productId = $model->getProductId($groupId);

        return $productId;
    }

    /**
     * Get currency symbol for current locale and currency code
     *
     * @return string
     */
    public function getCurrentCurrencySymbol()
    {
        return $this->_currency->getCurrencySymbol();
    }
}