<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block;

use Magento\Framework\View\Element\Template;

class Js extends Template
{

}