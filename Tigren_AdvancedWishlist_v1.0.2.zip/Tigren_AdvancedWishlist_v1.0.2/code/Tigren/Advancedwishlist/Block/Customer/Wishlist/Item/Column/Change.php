<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block\Customer\Wishlist\Item\Column;

class Change extends \Magento\Wishlist\Block\Customer\Wishlist\Item\Column
{

}
