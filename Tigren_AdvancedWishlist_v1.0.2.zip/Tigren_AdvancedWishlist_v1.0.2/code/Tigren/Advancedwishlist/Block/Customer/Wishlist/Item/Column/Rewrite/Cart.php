<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Block\Customer\Wishlist\Item\Column\Rewrite;

class Cart extends \Magento\Wishlist\Block\Customer\Wishlist\Item\Column\Cart
{
    public function getAddToCartQty(\Magento\Wishlist\Model\Item $item)
    {
        //fix blank space
        if (!empty($group = $this->_request->getParam('group'))) {
            $qty = $item->getQtyInGroup($group);
        } else {
            $qty = $item->getQty();
        }

        return $qty ? $qty : 1;
    }

}