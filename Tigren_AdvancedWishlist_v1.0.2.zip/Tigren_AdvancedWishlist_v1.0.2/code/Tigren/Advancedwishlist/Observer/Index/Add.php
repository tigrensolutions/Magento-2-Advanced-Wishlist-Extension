<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Tigren\WishlistPlus\Observer\Index;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Tigren\WishlistPlus\Model\GroupFactory;

class Add implements ObserverInterface
{
    /**
     * @var RequestInterface
     */
    protected $_request;

    /**
     * @var GroupFactory
     */
    protected $_group;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * Add constructor.
     * @param \Psr\Log\LoggerInterface $loggerInterface
     * @param RequestInterface $request
     * @param GroupFactory $group
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        RequestInterface $request,
        GroupFactory $group,
        \Magento\Framework\Registry $registry,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper,
        \Magento\Customer\Model\Session $customerSession
    )
    {
        $this->_customerSession = $customerSession;
        $this->_group = $group;
        $this->_request = $request;
        $this->_wishlistHelper = $wishlistHelper;
    }

    /**
     * This is the method that fires when the event runs.
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        if ($this->_wishlistHelper->isWishlistPlusEnable()) {
            $itemId = $observer->getData('item')->getId();
            $params = $this->_request->getParams();

            if (!empty($params['mb-select-group'])) {
                $groupId = $params['mb-select-group'];
                $groupModel = $this->_group->create()->load($groupId);
            } else {
                $groupName = $params['mb-group-name'];
                $groupDescription = $params['mb-group-description'];
                $groupModel = $this->_group->create();
                $groupModel->setGroupName($groupName);
                $groupModel->setDescription($groupDescription);
                $groupModel->setCustomerId($this->_customerSession->getCustomer()->getId());
                $groupModel->save();
            }

            $groupModel->updateWishlistProduct($itemId, $params['qty']);
        }
    }
}