<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Plugin\Model;

class Item
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    protected $_wishlistHelper;

    /**
     * Item constructor.
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_wishlistHelper = $wishlistHelper;
    }

    public function beforeAddToCart(\Magento\Wishlist\Model\Item $subject, \Magento\Checkout\Model\Cart $cart, $delete)
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            if ($this->getAddToCartConfig() == 0) {
                return [$cart, false];
            }
        }
    }

    public function getAddToCartConfig()
    {
        return $this->scopeConfig->getValue(
            'wishlistplus/general/cart',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }


}