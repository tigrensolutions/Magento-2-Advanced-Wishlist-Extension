<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Plugin\Model\ResourceModel\Item;

use Magento\Customer\Model\Session;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Registry;

class Collection extends \Magento\Wishlist\Model\ResourceModel\Item\Collection
{
    /**
     * @var Session
     */
    protected $_customerSession;

    /**
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * @var RequestInterface
     */
    protected $_request;

    /**
     * Product Visibility Filter to product collection flag
     *
     * @var bool
     */
    protected $_productVisible = false;

    /**
     * Product Salable Filter to product collection flag
     *
     * @var bool
     */
    protected $_productSalable = false;

    /**
     * If product out of stock, its item will be removed after load
     *
     * @var bool
     */
    protected $_productInStock = false;

    /**
     * Product Ids array
     *
     * @var array
     */
    protected $_productIds = [];

    /**
     * Store Ids array
     *
     * @var array
     */
    protected $_storeIds = [];

    /**
     * Add days in wishlist filter of product collection
     *
     * @var boolean
     */
    protected $_addDaysInWishlist = false;

    /**
     * Sum of items collection qty
     *
     * @var int
     */
    protected $_itemsQty;

    /**
     * Whether product name attribute value table is joined in select
     *
     * @var boolean
     */
    protected $_isProductNameJoined = false;

    /**
     * Adminhtml sales
     *
     * @var \Magento\Sales\Helper\Admin
     */
    protected $_adminhtmlSales = null;

    /**
     * Catalog inventory data
     *
     * @var \Magento\CatalogInventory\Api\StockConfigurationInterface
     */
    protected $stockConfiguration = null;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;

    /**
     * @var \Magento\Wishlist\Model\Config
     */
    protected $_wishlistConfig;

    /**
     * @var \Magento\Catalog\Model\Product\Visibility
     */
    protected $_productVisibility;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $_coreResource;

    /**
     * @var \Magento\Wishlist\Model\ResourceModel\Item\Option\CollectionFactory
     */
    protected $_optionCollectionFactory;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $_productCollectionFactory;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\ConfigFactory
     */
    protected $_catalogConfFactory;

    /**
     * @var \Magento\Catalog\Model\Entity\AttributeFactory
     */
    protected $_catalogAttrFactory;

    /**
     * @var \Magento\Framework\App\State
     */
    protected $_appState;

    /**
     * @var MetadataPool
     */
    protected $metadataPool;

    /**
     * @var
     */
    protected $customerSession;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * @param \Magento\Framework\Data\Collection\EntityFactory $entityFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\CatalogInventory\Api\StockConfigurationInterface $stockConfiguration
     * @param \Magento\Sales\Helper\Admin $adminhtmlSales
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     * @param \Magento\Wishlist\Model\Config $wishlistConfig
     * @param \Magento\Catalog\Model\Product\Visibility $productVisibility
     * @param \Magento\Framework\App\ResourceConnection $coreResource
     * @param \Magento\Wishlist\Model\ResourceModel\Item\Option\CollectionFactory $optionCollectionFactory
     * @param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     * @param \Magento\Catalog\Model\ResourceModel\ConfigFactory $catalogConfFactory
     * @param \Magento\Catalog\Model\Entity\AttributeFactory $catalogAttrFactory
     * @param \Magento\Wishlist\Model\ResourceModel\Item $resource
     * @param \Magento\Framework\App\State $appState
     * @param \Magento\Framework\DB\Adapter\AdapterInterface $connection
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Framework\Data\Collection\EntityFactory $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\CatalogInventory\Api\StockConfigurationInterface $stockConfiguration,
        \Magento\Sales\Helper\Admin $adminhtmlSales,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Wishlist\Model\Config $wishlistConfig,
        \Magento\Catalog\Model\Product\Visibility $productVisibility,
        \Magento\Framework\App\ResourceConnection $coreResource,
        \Magento\Wishlist\Model\ResourceModel\Item\Option\CollectionFactory $optionCollectionFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Catalog\Model\ResourceModel\ConfigFactory $catalogConfFactory,
        \Magento\Catalog\Model\Entity\AttributeFactory $catalogAttrFactory,
        \Magento\Wishlist\Model\ResourceModel\Item $resource,
        \Magento\Framework\App\State $appState,
        RequestInterface $request,
        Registry $registry,
        Session $customerSession,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper,
        \Magento\Framework\DB\Adapter\AdapterInterface $connection = null
    )
    {
        $this->_customerSession = $customerSession;
        $this->_coreRegistry = $registry;
        $this->_wishlistHelper = $wishlistHelper;
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $stockConfiguration,
            $adminhtmlSales, $storeManager, $date, $wishlistConfig, $productVisibility, $coreResource,
            $optionCollectionFactory, $productCollectionFactory, $catalogConfFactory, $catalogAttrFactory,
            $resource, $appState, $connection);

        $this->_request = $request;
    }

    /**
     * @param \Magento\Wishlist\Model\Wishlist $wishlist
     * @return $this
     */
    public function addWishlistFilter(\Magento\Wishlist\Model\Wishlist $wishlist)
    {
        if ($this->_wishlistHelper->isWishlistPlusEnable()) {
            $this->addGroupFilter();
            $this->addFieldToFilter('wishlist_id', $wishlist->getId());
            return $this;
        } else {
            $this->addFieldToFilter('wishlist_id', $wishlist->getId());
            return $this;
        }
    }

    /**
     * @return $this
     */
    public function addGroupFilter()
    {
        $groupId = $this->_request->getParam('group');

        if (empty($groupId)) {
            $groupId = $this->getGroupIdByWishlistItem();
        }

        if ($groupId) {
            $this->getSelect()->distinct(
                true
            )->join(
                ['wplus_group' => $this->getTable('tigren_wishlistplus_item')],
                "main_table.wishlist_item_id = wplus_group.tigren_wishlistplus_item_id AND wplus_group.group_id = $groupId",
                []
            );
        }
        return $this;
    }

    /**
     * @return string
     */
    public function getGroupIdByWishlistItem()
    {
        $data = $this->_request->getParam('qty');
        $wishlistId = $this->_request->getParam('wishlist_id');

        if (!empty($data) && !empty($wishlistId)) {
            if (is_array($data)) {
                foreach ($data as $key => $value) {
                    $tmp = $key;
                }

                $connection = $this->getConnection();
                $table = $this->getTable('tigren_wishlistplus_item');
                $sql = $connection->select()->from($table, 'group_id')->where("tigren_wishlistplus_item_id = $tmp");
                $id = $connection->fetchOne($sql);

                return $id;
            }
        }
    }

    /**
     * @return $this
     */

    protected function _beforeLoad()
    {
        return parent::_beforeLoad();
    }
}
