<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Plugin;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Checkout\Model\Cart as CustomerCart;
use Magento\Customer\Model\Session;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Tigren\WishlistPlus\Helper\Data as AjaxgroupData;
use Tigren\WishlistPlus\Model\GroupFactory;

class Add
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var AjaxgroupData Data
     */
    protected $_ajaxgroupData;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $_jsonEncode;

    /**
     * @var GroupFactory
     */
    protected $_groupFactory;

    /**
     * @var \Magento\Framework\Controller\Result\RedirectFactory
     */
    protected $resultRedirectFactory;

    /**
     * @var UrlInterface
     */
    protected $_urlBuilder;

    /**
     * @var Session
     */
    protected $_customerSession;

    /**
     * Logger
     *
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator
     * @param CustomerCart $cart
     * @param ProductRepositoryInterface $productRepository
     * @codeCoverageIgnore
     */
    public function __construct
    (
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        \Magento\Framework\Registry $registry,
        CustomerCart $cart,
        ProductRepositoryInterface $productRepository,
        AjaxgroupData $ajaxcartData,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\Json\Helper\Data $jsonEncode,
        GroupFactory $groupFactory,
        \Magento\Framework\Controller\Result\RedirectFactory $redirectFactory,
        UrlInterface $urlInterface,
        Session $customerSession,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->_logger = $logger;
        $this->_customerSession = $customerSession;
        $this->_urlBuilder = $urlInterface;
        $this->resultRedirectFactory = $redirectFactory;
        $this->_groupFactory = $groupFactory;
        $this->_jsonEncode = $jsonEncode;
        $this->messageManager = $messageManager;
        $this->_storeManager = $storeManager;
        $this->productRepository = $productRepository;
        $this->_ajaxgroupData = $ajaxcartData;
        $this->_wishlistHelper = $wishlistHelper;
        $this->_coreRegistry = $registry;
    }

    public function aroundExecute($subject, $proceed)
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            $result = [];
            if ($this->_customerSession->getCustomer()->getId()) {
                $params = $subject->getRequest()->getParams();

                $product = $this->_initProduct($subject);
                if (!empty($params['isAjax'])) {
                    try {
                        $this->_coreRegistry->register('product', $product);
                        $this->_coreRegistry->register('current_product', $product);
                        $htmlPopup = $this->_ajaxgroupData->getOptionsPopupHtml($product);
                        $result['success'] = true;
                        $result['html_popup'] = $htmlPopup;
                        $subject->getResponse()->representJson($this->_jsonEncode->jsonEncode($result));
                        return;
                    } catch (\Exception $e) {
                        $this->_logger->debug('Can not get product into plugin add', ['message' => $e->getMessage()]);
                    }
                }

                if (!empty($params['isPopupSubmit'])) {
                    $proceed();
                    $this->_coreRegistry->register('product', $product);
                    $this->_coreRegistry->register('current_product', $product);

                    $htmlPopup = $this->_ajaxgroupData->getSuccessHtml($product);
                    $result['success'] = true;
                    $result['html_popup'] = $htmlPopup;

                    $subject->getResponse()->representJson($this->_jsonEncode->jsonEncode($result));
                }
            } else {
                $backUrl = $this->_urlBuilder->getUrl('customer/account/login/');
                $result['backUrl'] = $backUrl;
                $subject->getResponse()->representJson($this->_jsonEncode->jsonEncode($result));
                return;
            }
        }else{
            $proceed();
        }
    }

    /**
     * Initialize product instance from request data
     *
     * @return \Magento\Catalog\Model\Product|false
     */
    protected function _initProduct($subject)
    {
        $productId = (int)$subject->getRequest()->getParam('product');
        if ($productId) {
            $storeId = $this->_storeManager->getStore()->getId();
            try {
                $product = $this->productRepository->getById($productId, false, $storeId);

                return $product;
            } catch (NoSuchEntityException $e) {
                return false;
            }
        }
        return false;
    }
}
