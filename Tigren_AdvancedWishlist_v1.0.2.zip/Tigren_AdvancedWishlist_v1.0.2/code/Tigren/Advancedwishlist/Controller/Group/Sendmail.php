<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Controller\Group;

use Magento\Framework\App\Action\Action;

class Sendmail extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $dataHelper;

    /**
     * @var \Tigren\WishlistPlus\Helper\Email
     */
    protected $_emailHelper;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Sendmail constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Tigren\WishlistPlus\Helper\Data $dataHelper
     * @param \Tigren\WishlistPlus\Helper\Email $emailHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Tigren\WishlistPlus\Helper\Data $dataHelper,
        \Tigren\WishlistPlus\Helper\Email $emailHelper,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_emailHelper = $emailHelper;
        $this->dataHelper = $dataHelper;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);

    }

    /**
     * @return $this|void
     */
    public function execute()
    {
        $params = $this->_request->getParams();
        $userName = $params['user_name'];
        $userMail = $params['user_email'];
        $userMessage = $params['user_message'];
        if (!empty($this->getStoreName())) {
            $storeName = $this->getStoreName();
        } else {
            $storeName = 'Tigren';
        }

        /* Receiver Detail  */
        $receiverInfo = [
            'name' => 'Reciver Name',
            'email' => $userMail
        ];

        /* Sender Detail  */
        $senderInfo = [
            'name' => $storeName,
            'email' => 'nguoichuadangki@gmail.com',
        ];

        /* Assign values for your template variables  */
        $emailTemplateVariables = array();
        $emailTempVariables['store_url'] = $this->_url->getBaseUrl();
        $emailTempVariables['myName'] = $userName;
        $emailTempVariables['myMessage'] = $userMessage;

        /* We write send mail function in helper because if we want to
           use same in other action then we can call it directly from helper */

        try {
            $this->_emailHelper->friendEmail(
                $emailTempVariables,
                $senderInfo,
                $receiverInfo
            );

            $this->messageManager->addSuccessMessage('Sent successful email!');
            return $this->resultRedirectFactory->create()->setPath('*/*/');

        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addNoticeMessage(
                $this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml($e->getMessage())
            );

        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('We can\'t sent email.'));
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            return;
        }
    }

    public function getStoreName()
    {
        return $this->scopeConfig->getValue(
            'general/store_information/name',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}