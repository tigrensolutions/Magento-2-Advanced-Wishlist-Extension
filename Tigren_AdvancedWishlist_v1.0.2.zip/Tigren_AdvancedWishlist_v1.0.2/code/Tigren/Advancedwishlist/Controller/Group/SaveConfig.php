<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Controller\Group;

use Magento\Framework\App\Action\Action;
use Tigren\WishlistPlus\Helper\Email;
use Tigren\WishlistPlus\Model\GroupFactory;

class SaveConfig extends Action
{
    /** @var  \Magento\Framework\View\Result\Page */
    protected $resultPageFactory;

    /**
     * @var \Tigren\WishlistPlus\Model\Group
     */
    protected $_groupFactory;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customer;

    /**
     * @var Email
     */
    protected $_emailHelper;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;

    /**
     * @var \Magento\Theme\Block\Html\Header\Logo
     */
    protected $_logo;

    /**
     * @var \Tigren\WishlistPlus\Model\ReminderFactory
     */
    protected $_reminder;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Theme\Block\Html\Header\Logo $logo,
        GroupFactory $groupFactory,
        Email $emailHelper,
        \Tigren\WishlistPlus\Model\ReminderFactory $reminderFactory,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
    ) {
        $this->_reminder = $reminderFactory;
        $this->_logo = $logo;
        $this->_date = $dateTime;
        $this->_customer = $customerSession;
        $this->_groupFactory = $groupFactory;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);

    }

    public function execute()
    {
        /*
         * Config send email reminder
         */
        $params = $this->_request->getParams();
        $internalNumber = $params['interval_number'];
        $reminderOption = $params['reminder_option'];
        $countNumber = $params['count_send'];
        /* Here we prepare data for our email  */
        $customerData = $this->_customer->getCustomerData();
        $idCustomer = $customerData->getId();

        try {
            /* call send mail method from helper or where you define it*/
            $modelReminder = $this->_reminder->create();
            $modelReminder->setCustomerId($idCustomer);
            $modelReminder->setInterval($internalNumber);
            $modelReminder->setReminderOption($reminderOption);
            $modelReminder->setCountNumber($countNumber);
            $modelReminder->setLasttimeSend();

            $modelReminder->save();

            $this->messageManager->addSuccessMessage('Save config successful!');
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\RuntimeException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving config.'));
        }
        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }
}