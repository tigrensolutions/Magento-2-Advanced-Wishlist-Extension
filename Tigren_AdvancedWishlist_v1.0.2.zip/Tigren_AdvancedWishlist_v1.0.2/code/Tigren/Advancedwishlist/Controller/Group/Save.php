<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Controller\Group;

use Magento\Framework\App\Action\Action;
use Tigren\WishlistPlus\Model\GroupFactory;

class Save extends Action
{
    /** @var  \Magento\Framework\View\Result\Page */
    protected $resultPageFactory;

    /**
     * @var \Tigren\WishlistPlus\Model\Group
     */
    protected $_groupFactory;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * Save constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param GroupFactory $groupFactory
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        GroupFactory $groupFactory,
        \Magento\Customer\Model\Session $customerSession
    ) {
        $this->_customerSession = $customerSession;
        $this->_groupFactory = $groupFactory;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);

    }

    /**
     * @return $this
     */
    public function execute()
    {
        $data = $this->_initData();

        $groupModel = $this->_groupFactory->create();
        $groupModel->setData($data);
        $groupModel->setCustomerId($this->_customerSession->getCustomer()->getId());
        try {
            $groupModel->save();
            $this->messageManager->addSuccessMessage('The wishlist group has been added successfully.');
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\RuntimeException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the wishlist group.'));
        }
        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }

    /**
     * @return array
     */
    protected function _initData()
    {
        $data = $this->getRequest()->getParams();
        $data['color'] = substr($data['color'], 1);

        return $data;
    }
}