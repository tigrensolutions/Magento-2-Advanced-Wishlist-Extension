<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Controller\Group;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Tigren\WishlistPlus\Model\GroupFactory;

class View extends Action
{

    /**
     * @var PageFactory
     */
    protected $resultPage;

    /**
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * @var GroupFactory
     */
    protected $_groupFactory;

    /**
     * View constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param Registry $registry
     * @param GroupFactory $groupFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        Registry $registry,
        GroupFactory $groupFactory
    ) {
        $this->_groupFactory = $groupFactory;
        $this->_coreRegistry = $registry;
        $this->resultPage = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $groupId = $this->_request->getParam('group');
        $groupModel = $this->_groupFactory->create()->load($groupId);

        $this->_coreRegistry->register('id', $this->_request->getParam('group'));
        $resultPage = $this->resultPage->create();
        $resultPage->getConfig()->getTitle()->set(__('My ' . $groupModel->getGroupName()));

        $navigationBlock = $resultPage->getLayout()->getBlock('customer_account_navigation');
        if ($navigationBlock) {
            $navigationBlock->setActive('wlplus/group');
        }

        return $resultPage;
    }

}