<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Controller\Group;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Registry;
use Tigren\WishlistPlus\Model\GroupFactory;

class Update extends Action
{
    /** @var  \Magento\Framework\View\Result\Page */
    protected $resultPageFactory;

    /**
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * @var GroupFactory
     */
    protected $_groupFactory;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_dataHelper;

    /**
     * Update constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param GroupFactory $groupFactory
     * @param Registry $registry
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        GroupFactory $groupFactory,
        \Tigren\WishlistPlus\Helper\Data $dataHelper,
        Registry $registry
    ) {
        $this->_dataHelper = $dataHelper;
        $this->_groupFactory = $groupFactory;
        $this->_coreRegistry = $registry;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);

    }

    /**
     * @return $this
     */
    public function execute()
    {
        $params = $this->_request->getParams();

        try {
            // ajax group
            if (!empty($params['isPopupChangeGroup'])) {
                $htmlPopup = $this->_dataHelper->getChangeGroupHtml();
                $item = $params['item'];
                $result['success'] = true;
                $result['item'] = $item;
                $result['html_popup'] = $htmlPopup;
                $this->getResponse()->representJson(
                    $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result)
                );

                return;
            }

            if (!empty($params['isChangeGroup'])) {
                $oldGroup = $params['groupIdOld'];
                $newGroup = $params['groupIdNew'];
                $wishlistItemId = $params['itemId'];
                $this->_coreRegistry->register('groupIdNew', $newGroup);
                $this->_coreRegistry->register('itemId', $wishlistItemId);

                $wishlistItemIds = $this->_groupFactory->create()->getWishlistPlusItemId($newGroup);

                if (in_array($wishlistItemId, $wishlistItemIds)) {
                    $qtyCurrent = $this->_groupFactory->create()->getQtyCurrent($wishlistItemId, $oldGroup);
                    $this->_groupFactory->create()->updateWishlistProductFromUpdateGroup($wishlistItemId, $newGroup,
                        $qtyCurrent);
                    $this->_groupFactory->create()->deleteWishlistProductFromUpdateGroup($wishlistItemId, $oldGroup);
                    $htmlPopup = $this->_dataHelper->getMessageSuccessChangeGroupHtml();
                    $result['success'] = true;
                    $result['html_popup'] = $htmlPopup;

                    $this->getResponse()->representJson(
                        $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result)
                    );
                    return;
                }

                $this->_groupFactory->create()->changeGroupforWishlistItem($oldGroup, $newGroup, $wishlistItemId);
                $htmlPopup = $this->_dataHelper->getMessageSuccessChangeGroupHtml();
                $result['success'] = true;
                $result['html_popup'] = $htmlPopup;

                $this->getResponse()->representJson(
                    $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result)
                );

                return;
            }

            $this->_groupFactory->create()->updateGroup($params['group_name'], $params['group-id']);
            $this->messageManager->addSuccessMessage('Updated successfully!');
            return $this->resultRedirectFactory->create()->setPath('*/*/view/group/' . $params['group-id']);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\RuntimeException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('Something went wrong while update group.'));
        }
        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }
}