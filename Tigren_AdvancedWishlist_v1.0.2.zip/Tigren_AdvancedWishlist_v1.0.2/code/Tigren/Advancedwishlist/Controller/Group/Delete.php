<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Controller\Group;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Exception\NotFoundException;
use Magento\Wishlist\Controller\WishlistProviderInterface;
use Tigren\WishlistPlus\Model\GroupFactory;

class Delete extends Action
{
    /** @var  \Magento\Framework\View\Result\Page */
    protected $resultPageFactory;

    /**
     * @var \Tigren\WishlistPlus\Model\Group
     */
    protected $_groupFactory;

    /**
     * @var \Magento\Wishlist\Model\ItemFactory
     */
    protected $_itemFactory;

    /**
     * @var WishlistProviderInterface
     */
    protected $wishlistProvider;

    /**
     * Delete constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param GroupFactory $groupFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        GroupFactory $groupFactory,
        \Magento\Wishlist\Model\ItemFactory $itemFactory,
        WishlistProviderInterface $wishlistProvider
    ) {
        $this->wishlistProvider = $wishlistProvider;
        $this->_itemFactory = $itemFactory;
        $this->_groupFactory = $groupFactory;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);

    }

    /**
     * @return $this
     */
    public function execute()
    {
        $groupId = $this->_initData();
        try {
            $groupModel = $this->_groupFactory->create();
            $groupModel->load($groupId);
            $ids = $groupModel->getFromGroupId($groupId);
            foreach ($ids as $id) {
                $groupModel->updateQtyGroupRemove($id['tigren_wishlistplus_item_id'], $groupId, $id['product_qty']);
                $qty = $this->_groupFactory->create()->getQtyFromWishlistItem($id['tigren_wishlistplus_item_id']);

                if ($qty == 0) {
                    $item = $this->_objectManager->create('Magento\Wishlist\Model\Item')->load($id['tigren_wishlistplus_item_id']);
                    if (!$item->getId()) {
                        throw new NotFoundException(__('Page not found.'));
                    }
                    $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
                    if (!$wishlist) {
                        throw new NotFoundException(__('Page not found.'));
                    }
                    $item->delete();
                    $wishlist->save();
                }
            }

            $groupModel->delete();
            $this->messageManager->addSuccessMessage('Group has been deleted successfully!');
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\RuntimeException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the group.'));
        }
        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }

    /**
     * Init group
     *
     * @return mixed
     */
    protected function _initData()
    {
        return $this->getRequest()->getParam('id');
    }
}