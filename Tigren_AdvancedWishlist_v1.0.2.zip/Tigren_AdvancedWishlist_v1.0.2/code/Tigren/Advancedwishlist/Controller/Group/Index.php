<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Controller\Group;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Exception\NoSuchEntityException;
use Tigren\WishlistPlus\Model\GroupFactory;

class Index extends Action
{
    /** @var  \Magento\Framework\View\Result\Page */
    protected $resultPageFactory;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * @var \Magento\Catalog\Model\ProductRepository
     */
    protected $_productRepository;

    /**
     * Currently selected store ID if applicable
     *
     * @var int
     */
    protected $_storeManager;

    /**
     * @var GroupFactory
     */
    protected $_groupFactory;

    /**
     * @var \Magento\Framework\Data\Helper\PostHelper
     */
    protected $postDataHelper;


    /**
     * Index constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Data\Helper\PostHelper $postDataHelper,
        GroupFactory $groupFactory
    ) {
        $this->postDataHelper = $postDataHelper;
        $this->_groupFactory = $groupFactory;
        $this->_storeManager = $storeManager;
        $this->_productRepository = $productRepository;
        $this->_wishlistHelper = $wishlistHelper;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
    }

    /**
     *
     * @return \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            $groupId = $this->getRequest()->getParam('id_group');
            $productId = $this->getRequest()->getParam('id_product');
            $groupModel = $this->_groupFactory->create()->load($groupId);


            /** @var \Magento\Framework\View\Result\Page $resultPage */
            $resultPage = $this->resultPageFactory->create();

            $resultPage->getConfig()->getTitle()->set(__('My Wishlist'));

            if ($this->checkLogin() == 1) {
                return $resultPage;
            } else {
                return $this->resultRedirectFactory->create()->setPath('customer/account/login/');
            }
        }else{
            $this->_redirect($this->_url->getUrl('wishlist'));
        }
    }

    /**
     * @return int
     */
    public function checkLogin()
    {
        return $this->_wishlistHelper->checkLogin();
    }

    /**
     * @return bool|\Magento\Catalog\Api\Data\ProductInterface|mixed
     */
    protected function _initProduct()
    {
        $productId = $this->getRequest()->getParam('id_group');
        if ($productId) {
            $storeId = $this->_storeManager->getStore()->getId();

            try {
                $product = $this->_productRepository->getById($productId, false, $storeId);
                return $product;
            } catch (NoSuchEntityException $e) {
                return false;
            }
        }
        return false;
    }

}