<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Tigren\WishlistPlus\Controller\Index\Rewrite;

use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Wishlist\Controller\WishlistProviderInterface;
use Magento\Wishlist\Model\Product\AttributeValueProvider;

class Remove extends \Magento\Wishlist\Controller\Index\Remove
{
    /**
     * @var \Tigren\WishlistPlus\Model\GroupFactory
     */
    protected $_groupFactory;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;


    /**
     * @var AttributeValueProvider
     */
    private $attributeValueProvider;

    /**
     * Remove constructor.
     * @param Action\Context $context
     * @param WishlistProviderInterface $wishlistProvider
     * @param Validator $formKeyValidator
     * @param \Tigren\WishlistPlus\Helper\Data $wishlistHelper
     * @param \Tigren\WishlistPlus\Model\GroupFactory $groupFactory
     * @param AttributeValueProvider|null $attributeValueProvider
     */
    public function __construct
    (
        Action\Context $context,
        WishlistProviderInterface $wishlistProvider,
        Validator $formKeyValidator,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper,
        \Tigren\WishlistPlus\Model\GroupFactory $groupFactory,
        AttributeValueProvider $attributeValueProvider = null
    ) {
        $this->_groupFactory = $groupFactory;
        $this->_wishlistHelper = $wishlistHelper;
        $this->attributeValueProvider = $attributeValueProvider
            ?: \Magento\Framework\App\ObjectManager::getInstance()->get(AttributeValueProvider::class);
        parent::__construct($context, $wishlistProvider, $formKeyValidator);
    }

    /**
     * @return \Magento\Framework\Controller\Result\Redirect
     * @throws NotFoundException
     */
    public function execute()
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            if (!$this->formKeyValidator->validate($this->getRequest())) {
                return $resultRedirect->setPath('*/*/');
            }

            $id = (int)$this->getRequest()->getParam('item');
            $item = $this->_objectManager->create('Magento\Wishlist\Model\Item')->load($id);
            if (!$item->getId()) {
                throw new NotFoundException(__('Page not found.'));
            }
            $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
            if (!$wishlist) {
                throw new NotFoundException(__('Page not found.'));
            }
            /**
             * Get params
             */
            $params = $this->_request->getParams();
            $groupId = $params['groupId'];
            try {
                if (!empty($groupId)) {
                    $model = $this->_groupFactory->create();
                    $wishlistItemId = $params['item'];
                    $qty = $model->getQtyCurrent($wishlistItemId, $groupId);

                    /**
                     * end params
                     */
                    $model->updateQtyGroupRemove($wishlistItemId, $groupId, $qty);
                } else {
                    $item->delete();
                    $wishlist->save();
                }

            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError(
                    __('We can\'t delete the item from Wish List right now because of an error: %1.', $e->getMessage())
                );
            } catch (\Exception $e) {
                $this->messageManager->addError(__('We can\'t delete the item from the Wish List right now.'));
            }

            $this->_objectManager->get('Magento\Wishlist\Helper\Data')->calculate();
            $request = $this->getRequest();
            $refererUrl = (string)$request->getServer('HTTP_REFERER');
            $url = (string)$request->getParam(\Magento\Framework\App\Response\RedirectInterface::PARAM_NAME_REFERER_URL);
            if ($url) {
                $refererUrl = $url;
            }
            if ($request->getParam(\Magento\Framework\App\ActionInterface::PARAM_NAME_URL_ENCODED) && $refererUrl) {
                $redirectUrl = $refererUrl;
            } else {
                $redirectUrl = $this->_redirect->getRedirectUrl($this->_url->getUrl('*/*'));
            }
            $resultRedirect->setUrl($redirectUrl);
            return $resultRedirect;
        }else{
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            if (!$this->formKeyValidator->validate($this->getRequest())) {
                return $resultRedirect->setPath('*/*/');
            }

            $id = (int)$this->getRequest()->getParam('item');
            /** @var Item $item */
            $item = $this->_objectManager->create(Item::class)->load($id);
            if (!$item->getId()) {
                throw new NotFoundException(__('Page not found.'));
            }
            $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
            if (!$wishlist) {
                throw new NotFoundException(__('Page not found.'));
            }
            try {
                $item->delete();
                $wishlist->save();
                $productName = $this->attributeValueProvider
                    ->getRawAttributeValue($item->getProductId(), 'name');
                $this->messageManager->addComplexSuccessMessage(
                    'removeWishlistItemSuccessMessage',
                    [
                        'product_name' => $productName,
                    ]
                );
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError(
                    __('We can\'t delete the item from Wish List right now because of an error: %1.', $e->getMessage())
                );
            } catch (\Exception $e) {
                $this->messageManager->addError(__('We can\'t delete the item from the Wish List right now.'));
            }

            $this->_objectManager->get(\Magento\Wishlist\Helper\Data::class)->calculate();
            $refererUrl = $this->_redirect->getRefererUrl();
            if ($refererUrl) {
                $redirectUrl = $refererUrl;
            } else {
                $redirectUrl = $this->_redirect->getRedirectUrl($this->_url->getUrl('*/*'));
            }
            $resultRedirect->setUrl($redirectUrl);
            return $resultRedirect;
        }
    }
}