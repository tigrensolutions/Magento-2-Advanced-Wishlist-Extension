<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Tigren\WishlistPlus\Controller\Index\Rewrite;

use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\NotFoundException;

class Configure extends \Magento\Wishlist\Controller\Index\Configure
{
    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * Configure constructor.
     * @param Action\Context $context
     * @param \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Tigren\WishlistPlus\Helper\Data $wishlistHelper
     */
    public function __construct(
        Action\Context $context,
        \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper)
    {
        parent::__construct($context, $wishlistProvider, $coreRegistry, $resultPageFactory);
        $this->_wishlistHelper = $wishlistHelper;
    }

    /**
     * @return \Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        if ($this->_wishlistHelper->isWishlistPlusEnable()) {
            $id = (int)$this->getRequest()->getParam('id');
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            try {
                /* @var $item \Magento\Wishlist\Model\Item */
                $item = $this->_objectManager->create('Magento\Wishlist\Model\Item');
                $item->loadWithOptions($id);
                if (!$item->getId()) {
                    throw new \Magento\Framework\Exception\LocalizedException(
                        __('We can\'t load the Wish List item right now.')
                    );
                }
                $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
                if (!$wishlist) {
                    throw new NotFoundException(__('Page not found.'));
                }

                $this->_coreRegistry->register('wishlist_item', $item);

                $params = new \Magento\Framework\DataObject();
                $params->setCategoryId(false);
                $params->setConfigureMode(true);
                $buyRequest = $item->getBuyRequest();
                /**
                 * Get qty in group
                 */
                $groupSelected = $this->_request->getParam('groupId');
                if (!empty($groupSelected)) {
                    $buyRequest->setQty($item->getQtyInGroup($groupSelected));
                }

                // END //
                if (!$buyRequest->getQty() && $item->getQty()) {
                    $buyRequest->setQty($item->getQty());
                }
                if ($buyRequest->getQty() && !$item->getQty()) {
                    $item->setQty($buyRequest->getQty());
                    $this->_objectManager->get('Magento\Wishlist\Helper\Data')->calculate();
                }
                $params->setBuyRequest($buyRequest);

                $data = $params->getData();
                /** @var \Magento\Framework\View\Result\Page $resultPage */
                $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
                $this->_objectManager->get(
                    'Magento\Catalog\Helper\Product\View'
                )->prepareAndRender(
                    $resultPage,
                    $item->getProductId(),
                    $this,
                    $params
                );

                return $resultPage;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
                $resultRedirect->setPath('*');
                return $resultRedirect;
            } catch (\Exception $e) {
                $this->messageManager->addError(__('We can\'t configure the product right now.'));
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                $resultRedirect->setPath('*');
                return $resultRedirect;
            }
        } else {
            $id = (int)$this->getRequest()->getParam('id');
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            try {
                /* @var $item \Magento\Wishlist\Model\Item */
                $item = $this->_objectManager->create(\Magento\Wishlist\Model\Item::class);
                $item->loadWithOptions($id);
                if (!$item->getId()) {
                    throw new \Magento\Framework\Exception\LocalizedException(
                        __("The Wish List item can't load at this time. Please try again later.")
                    );
                }
                $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
                if (!$wishlist) {
                    throw new NotFoundException(__('Page not found.'));
                }

                $this->_coreRegistry->register('wishlist_item', $item);

                $params = new \Magento\Framework\DataObject();
                $params->setCategoryId(false);
                $params->setConfigureMode(true);
                $buyRequest = $item->getBuyRequest();
                if (!$buyRequest->getQty() && $item->getQty()) {
                    $buyRequest->setQty($item->getQty());
                }
                if ($buyRequest->getQty() && !$item->getQty()) {
                    $item->setQty($buyRequest->getQty());
                    $this->_objectManager->get(\Magento\Wishlist\Helper\Data::class)->calculate();
                }
                $params->setBuyRequest($buyRequest);
                /** @var \Magento\Framework\View\Result\Page $resultPage */
                $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
                $this->_objectManager->get(
                    \Magento\Catalog\Helper\Product\View::class
                )->prepareAndRender(
                    $resultPage,
                    $item->getProductId(),
                    $this,
                    $params
                );

                return $resultPage;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
                $resultRedirect->setPath('*');
                return $resultRedirect;
            } catch (\Exception $e) {
                $this->messageManager->addError(__('We can\'t configure the product right now.'));
                $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
                $resultRedirect->setPath('*');
                return $resultRedirect;
            }
        }
    }
}
