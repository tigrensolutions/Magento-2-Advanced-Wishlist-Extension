<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Tigren\WishlistPlus\Controller\Index\Rewrite;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Registry;
use Magento\Wishlist\Controller\WishlistProviderInterface;
use Tigren\WishlistPlus\Model\GroupFactory;

class UpdateItemOptions extends \Magento\Wishlist\Controller\Index\UpdateItemOptions
{
    /**
     * @var GroupFactory
     */
    protected $_group;

    /**
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * UpdateItemOptions constructor.
     * @param Action\Context $context
     * @param Session $customerSession
     * @param WishlistProviderInterface $wishlistProvider
     * @param ProductRepositoryInterface $productRepository
     * @param Validator $formKeyValidator
     * @param GroupFactory $groupFactory
     * @param \Tigren\WishlistPlus\Helper\Data $wishlistHelper
     * @param Registry $registry
     */
    public function __construct
    (
        Action\Context $context,
        Session $customerSession,
        WishlistProviderInterface $wishlistProvider,
        ProductRepositoryInterface $productRepository,
        Validator $formKeyValidator,
        GroupFactory $groupFactory,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper,
        Registry $registry
    ) {
        $this->_coreRegistry = $registry;
        $this->_group = $groupFactory;
        $this->_wishlistHelper = $wishlistHelper;
        parent::__construct($context, $customerSession, $wishlistProvider, $productRepository, $formKeyValidator);
    }


    /**
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            $groupId = (int)$this->getRequest()->getParam('groupId');
            if (empty($groupId)) {
                $groupId = 1;
            }
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            if (!$this->formKeyValidator->validate($this->getRequest())) {
                return $resultRedirect->setPath('*/*/');
            }

            $productId = (int)$this->getRequest()->getParam('product');
            if (!$productId) {
                $resultRedirect->setPath('*/');
                return $resultRedirect;
            }

            try {
                $product = $this->productRepository->getById($productId);
            } catch (NoSuchEntityException $e) {
                $product = null;
            }

            if (!$product || !$product->isVisibleInCatalog()) {
                $this->messageManager->addError(__('We can\'t specify a product.'));
                $resultRedirect->setPath('*/');
                return $resultRedirect;
            }

            try {
                $id = (int)$this->getRequest()->getParam('id');
                $groupId = (int)$this->getRequest()->getParam('groupId');
                $qty = (int)$this->getRequest()->getParam('qty');
                /* @var \Magento\Wishlist\Model\Item */
                $item = $this->_objectManager->create('Magento\Wishlist\Model\Item');
                $item->load($id);
                $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
                if (!$wishlist) {
                    $resultRedirect->setPath('*/');
                    return $resultRedirect;
                }


                /*
                 * Update qty in group
                 */
                $this->_group->create()->updateQtyGroupEdit($id, $groupId, $qty);

                /*
                 * Update qty in wishlist core
                 */
                $buyRequest = new \Magento\Framework\DataObject($this->getRequest()->getParams());
                /*
                 * Qty product in all group
                 */
                $qtyProduct = $this->_group->create()->getQtysInAllGroup($id);
                $buyRequest->setData('qty', $qtyProduct);

                $this->_coreRegistry->register('groupIdInUpdate', $groupId);

                $wishlist->updateItem($id, $buyRequest)->save();

                $this->_objectManager->get('Magento\Wishlist\Helper\Data')->calculate();

                $this->_eventManager->dispatch(
                    'wishlist_update_item',
                    ['wishlist' => $wishlist, 'product' => $product, 'item' => $wishlist->getItem($id)]
                );

                $this->_objectManager->get('Magento\Wishlist\Helper\Data')->calculate();

                $message = __('%1 has been updated in your Wish List.', $product->getName());
                $this->messageManager->addSuccess($message);
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addError(__('We can\'t update your Wish List right now.'));
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            }
            if (!empty($groupId)) {
                $resultRedirect->setPath('wlplus/group/view', ['group' => $groupId]);
            } else {
                $resultRedirect->setPath('*/*', ['wishlist_id' => $wishlist->getId()]);
            }
            return $resultRedirect;
        }else{
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            if (!$this->formKeyValidator->validate($this->getRequest())) {
                return $resultRedirect->setPath('*/*/');
            }

            $productId = (int)$this->getRequest()->getParam('product');
            if (!$productId) {
                $resultRedirect->setPath('*/');
                return $resultRedirect;
            }

            try {
                $product = $this->productRepository->getById($productId);
            } catch (NoSuchEntityException $e) {
                $product = null;
            }

            if (!$product || !$product->isVisibleInCatalog()) {
                $this->messageManager->addError(__('We can\'t specify a product.'));
                $resultRedirect->setPath('*/');
                return $resultRedirect;
            }

            try {
                $id = (int)$this->getRequest()->getParam('id');
                /* @var \Magento\Wishlist\Model\Item */
                $item = $this->_objectManager->create(\Magento\Wishlist\Model\Item::class);
                $item->load($id);
                $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
                if (!$wishlist) {
                    $resultRedirect->setPath('*/');
                    return $resultRedirect;
                }

                $buyRequest = new \Magento\Framework\DataObject($this->getRequest()->getParams());

                $wishlist->updateItem($id, $buyRequest)->save();

                $this->_objectManager->get(\Magento\Wishlist\Helper\Data::class)->calculate();
                $this->_eventManager->dispatch(
                    'wishlist_update_item',
                    ['wishlist' => $wishlist, 'product' => $product, 'item' => $wishlist->getItem($id)]
                );

                $this->_objectManager->get(\Magento\Wishlist\Helper\Data::class)->calculate();

                $message = __('%1 has been updated in your Wish List.', $product->getName());
                $this->messageManager->addSuccess($message);
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addError(__('We can\'t update your Wish List right now.'));
                $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
            }
            $resultRedirect->setPath('*/*', ['wishlist_id' => $wishlist->getId()]);
            return $resultRedirect;
        }
    }
}
