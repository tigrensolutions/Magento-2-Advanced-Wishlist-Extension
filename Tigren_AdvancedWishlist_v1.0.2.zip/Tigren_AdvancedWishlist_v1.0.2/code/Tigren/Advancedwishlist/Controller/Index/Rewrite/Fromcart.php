<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Tigren\WishlistPlus\Controller\Index\Rewrite;

use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Helper\Cart as CartHelper;
use Magento\Checkout\Model\Cart as CheckoutCart;
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Registry;
use Magento\Wishlist\Controller\WishlistProviderInterface;
use Magento\Wishlist\Helper\Data as WishlistHelper;

class Fromcart extends \Magento\Wishlist\Controller\Index\Fromcart
{

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_ajaxgroupData;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $_jsonEncode;


    /**
     * Fromcart constructor.
     * @param Action\Context $context
     * @param WishlistProviderInterface $wishlistProvider
     * @param WishlistHelper $wishlistHelper
     * @param CheckoutCart $cart
     * @param CartHelper $cartHelper
     * @param Escaper $escaper
     * @param ProductRepository $productRepository
     * @param Validator $formKeyValidator
     * @param Registry $registry
     * @param \Tigren\WishlistPlus\Helper\Data $data
     * @param \Magento\Framework\Json\Helper\Data $jsonEncode
     */
    public function __construct(
        Action\Context $context,
        WishlistProviderInterface $wishlistProvider,
        WishlistHelper $wishlistHelper,
        CheckoutCart $cart,
        CartHelper $cartHelper,
        Escaper $escaper,
        ProductRepository $productRepository,
        Validator $formKeyValidator,
        Registry $registry,
        \Tigren\WishlistPlus\Helper\Data $data,
        \Magento\Framework\Json\Helper\Data $jsonEncode
    )
    {
        $this->_jsonEncode = $jsonEncode;
        $this->_ajaxgroupData = $data;
        $this->_coreRegistry = $registry;
        $this->productRepository = $productRepository;
        parent::__construct($context, $wishlistProvider, $wishlistHelper, $cart, $cartHelper, $escaper,
            $formKeyValidator);
    }


    /**
     * @return $this|\Magento\Framework\Controller\Result\Redirect
     * @throws NotFoundException
     */
    public function execute()
    {
        if ($this->_ajaxgroupData->isWishlistPlusEnable()) {
            $params = $this->_request->getParams();
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            if (!$this->formKeyValidator->validate($this->getRequest())) {
                return $resultRedirect->setPath('*/*/');
            }

            $wishlist = $this->wishlistProvider->getWishlist();
            if (!$wishlist) {
                throw new NotFoundException(__('Page not found.'));
            }

            try {
                $itemId = (int)$this->getRequest()->getParam('item');
                $item = $this->cart->getQuote()->getItemById($itemId);
                if (!$item) {
                    throw new LocalizedException(
                        __('The requested cart item doesn\'t exist.')
                    );
                }

                $productId = $item->getProductId();
                $buyRequest = $item->getBuyRequest();

                $product = $this->productRepository->getById($productId);

                /*$wishlist->addNewItem($productId, $buyRequest);*/

                $this->cart->getQuote()->removeItem($itemId);
                $this->cart->save();

                $this->wishlistHelper->calculate();
                $wishlist->save();

                /*$this->messageManager->addSuccessMessage(__(
                    "%1 has been moved to your wish list.",
                    $this->escaper->escapeHtml($item->getProduct()->getName())
                ));
                */
                //OVERRIDE
                $this->_coreRegistry->register('product', $product);
                $this->_coreRegistry->register('current_product', $product);
                $htmlPopup = $this->_ajaxgroupData->getOptionsPopupHtml($product);
                $result['success'] = true;
                $result['html_popup'] = $htmlPopup;
                $this->getResponse()->representJson($this->_jsonEncode->jsonEncode($result));
                return;
                //OVERRIDE
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('We can\'t move the item to the wish list.'));
            }
            return $resultRedirect->setUrl($this->cartHelper->getCartUrl());
        } else {
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            if (!$this->formKeyValidator->validate($this->getRequest())) {
                return $resultRedirect->setPath('*/*/');
            }

            $wishlist = $this->wishlistProvider->getWishlist();
            if (!$wishlist) {
                throw new NotFoundException(__('Page not found.'));
            }

            try {
                $itemId = (int)$this->getRequest()->getParam('item');
                $item = $this->cart->getQuote()->getItemById($itemId);
                if (!$item) {
                    throw new LocalizedException(
                        __("The cart item doesn't exist.")
                    );
                }

                $productId = $item->getProductId();
                $buyRequest = $item->getBuyRequest();
                $wishlist->addNewItem($productId, $buyRequest);

                $this->cart->getQuote()->removeItem($itemId);
                $this->cart->save();

                $this->wishlistHelper->calculate();
                $wishlist->save();

                $this->messageManager->addSuccessMessage(__(
                    "%1 has been moved to your wish list.",
                    $this->escaper->escapeHtml($item->getProduct()->getName())
                ));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('We can\'t move the item to the wish list.'));
            }
            return $resultRedirect->setUrl($this->cartHelper->getCartUrl());
        }
    }
}
