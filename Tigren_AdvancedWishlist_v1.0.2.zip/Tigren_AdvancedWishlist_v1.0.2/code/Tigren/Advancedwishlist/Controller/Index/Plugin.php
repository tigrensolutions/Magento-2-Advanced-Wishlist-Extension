<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Tigren\WishlistPlus\Controller\Index;

use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Response\RedirectInterface;

class Plugin extends \Magento\Wishlist\Controller\Index\Plugin
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Magento\Wishlist\Model\AuthenticationStateInterface
     */
    protected $authenticationState;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $config;

    /**
     * @var \Magento\Framework\App\Response\RedirectInterface
     */
    protected $redirector;

    /**
     * Core url
     *
     * @var \Magento\Framework\Url\Helper\Data|null
     */
    protected $_coreUrl = null;

    /**
     * SID resolver
     *
     * @var \Magento\Framework\Session\SidResolverInterface
     */
    protected $sidResolver;

    /**
     * Storage
     *
     * @var \Magento\Framework\Session\StorageInterface
     */
    protected $storage;

    /**
     * @var \Magento\Framework\UrlFactory
     */
    protected $_urlFactory;

    /**
     * @var \Magento\Framework\Session\Generic
     */
    protected $_session;

    /**
     * Customer URL
     *
     * @var \Magento\Customer\Model\Url
     */
    protected $_customerUrl;

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $messageManager;

    /**
     * @param CustomerSession $customerSession
     * @param \Magento\Wishlist\Model\AuthenticationStateInterface $authenticationState
     * @param ScopeConfigInterface $config
     * @param RedirectInterface $redirector
     */
    public function __construct(
        CustomerSession $customerSession,
        \Magento\Wishlist\Model\AuthenticationStateInterface $authenticationState,
        ScopeConfigInterface $config,
        RedirectInterface $redirector,
        \Magento\Framework\Url\Helper\Data $coreUrl,
        \Magento\Framework\Session\SidResolverInterface $sidResolver,
        \Magento\Framework\Session\StorageInterface $storage,
        \Magento\Framework\UrlFactory $urlFactory,
        \Magento\Framework\Session\Generic $session,
        \Magento\Customer\Model\Url $customerUrl,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        $this->customerSession = $customerSession;
        $this->authenticationState = $authenticationState;
        $this->config = $config;
        $this->redirector = $redirector;
        $this->_coreUrl = $coreUrl;
        $this->sidResolver = $sidResolver;
        $this->storage = $storage;
        $this->_urlFactory = $urlFactory;
        $this->_session = $session;
        $this->_customerUrl = $customerUrl;
        $this->_wishlistHelper = $wishlistHelper;
        $this->messageManager = $messageManager;
    }

    /**
     * @param \Magento\Framework\App\ActionInterface $subject
     * @param RequestInterface $request
     */
    public function beforeDispatch(\Magento\Framework\App\ActionInterface $subject, RequestInterface $request)
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            $customerSession = $this->customerSession;

            if ($this->authenticationState->isEnabled() && !$customerSession->isLoggedIn()) {
                $this->setBeforeAuthUrl($this->_createUrl()->getUrl('*//*', ['_current' => true]));
            }
        }else{
            if ($this->authenticationState->isEnabled() && !$this->customerSession->authenticate()) {
                $subject->getActionFlag()->set('', 'no-dispatch', true);
                if (!$this->customerSession->getBeforeWishlistUrl()) {
                    $this->customerSession->setBeforeWishlistUrl($this->redirector->getRefererUrl());
                }
                $this->customerSession->setBeforeWishlistRequest($request->getParams());
                $this->customerSession->setBeforeRequestParams($this->customerSession->getBeforeWishlistRequest());
                $this->customerSession->setBeforeModuleName('wishlist');
                $this->customerSession->setBeforeControllerName('index');
                $this->customerSession->setBeforeAction('add');

                if ($request->getActionName() == 'add') {
                    $this->messageManager->addErrorMessage(__('You must login or register to add items to your wishlist.'));
                }
            }
            if (!$this->config->isSetFlag('wishlist/general/active')) {
                throw new NotFoundException(__('Page not found.'));
            }
        }
    }

    /**
     * Set Before auth url
     *
     * @param string $url
     * @return $this
     */
    public function setBeforeAuthUrl($url)
    {
        return $this->_setAuthUrl('before_auth_url', $url);
    }

    /**
     * Set auth url
     *
     * @param string $key
     * @param string $url
     * @return $this
     */
    protected function _setAuthUrl($key, $url)
    {
        $url = $this->_coreUrl->removeRequestParam($url,
            $this->sidResolver->getSessionIdQueryParam($this->customerSession));
        // Add correct session ID to URL if needed
        $url = $this->_createUrl()->getRebuiltUrl($url);
        return $this->storage->setData($key, $url);
    }

    /**
     * @return \Magento\Framework\UrlInterface
     */
    protected function _createUrl()
    {
        return $this->_urlFactory->create();
    }
}
