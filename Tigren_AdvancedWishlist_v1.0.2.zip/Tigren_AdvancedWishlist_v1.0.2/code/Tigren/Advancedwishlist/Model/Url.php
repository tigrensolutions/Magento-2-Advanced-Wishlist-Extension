<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model;

use Magento\Framework\UrlInterface;

class Url
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    public function __construct(
        UrlInterface $urlBuilder
    ) {
        $this->urlBuilder = $urlBuilder;
    }

    /**
     * Retrieve link to group url
     *
     * @return string
     */
    public function getGroupUrl()
    {
        return $this->urlBuilder->getUrl('wlplus/group/index');
    }
}