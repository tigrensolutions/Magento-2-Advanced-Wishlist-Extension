<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\UrlInterface;
use Psr\Log\LoggerInterface;

class Cron
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var \Tigren\WishlistPlus\Controller\Group\SaveConfig
     */
    protected $_saveConfig;

    /**
     * @var ReminderFactory
     */
    protected $_reminderFactory;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customer;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $_timezoneInterface;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_dateTime;

    /**
     * @var RequestInterface
     */
    protected $_request;

    /**
     * @var \Tigren\WishlistPlus\Helper\Email
     */
    protected $_emailHelper;

    /**
     * @var UrlInterface
     */
    protected $_url;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Cron constructor.
     * @param LoggerInterface $logger
     * @param \Tigren\WishlistPlus\Controller\Group\SaveConfig $saveConfig
     * @param ReminderFactory $reminderFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezoneInterface
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param RequestInterface $request
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Tigren\WishlistPlus\Helper\Email $emailHelper
     * @param UrlInterface $url
     */
    public function __construct(
        LoggerInterface $logger,
        \Tigren\WishlistPlus\Controller\Group\SaveConfig $saveConfig,
        \Tigren\WishlistPlus\Model\ReminderFactory $reminderFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezoneInterface,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        RequestInterface $request,
        \Magento\Customer\Model\Session $customerSession,
        \Tigren\WishlistPlus\Helper\Email $emailHelper,
        UrlInterface $url,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_url = $url;
        $this->_customer = $customerSession;
        $this->_emailHelper = $emailHelper;
        $this->_request = $request;
        $this->_dateTime = $dateTime;
        $this->_timezoneInterface = $timezoneInterface;
        $this->_reminderFactory = $reminderFactory;
        $this->logger = $logger;
        $this->_saveConfig = $saveConfig;
    }

    /**
     * @param string $dateTime
     * @return string $dateTime as time zone
     */
    public function getTimeAccordingToTimeZone($dateTime)
    {
        // for get current time according to time zone
        $today = $this->_timezoneInterface->date()->format('m/d/y H:i:s');

        // for convert date time according to magento time zone
        $dateTimeAsTimeZone = $this->_timezoneInterface
            ->date(new \DateTime($dateTime))
            ->format('m/d/y H:i:s');
        return $dateTimeAsTimeZone;
    }

    /**
     * Send email reminder
     */
    public function cronSendEmailReminder()
    {
        $customerData = $this->_customer->getCustomerData();
        $emailCustomer = $customerData->getEmail();

        /* Receiver Detail  */
        $receiverInfo = [
            'name' => 'Reciver Name',
            'email' => $emailCustomer
        ];

        /* Sender Detail  */
        $senderInfo = [
            'name' => $this->getStoreName(),
            'email' => 'nguoichuadangki@gmail.com',
        ];

        /* Assign values for your template variables  */
        $emailTemplateVariables = array();
        $emailTempVariables['store_url'] = $this->_url->getBaseUrl();
        $emailTempVariables['myName'] = $customerData->getFirstname();

        /* We write send mail function in helper because if we want to
           use same in other action then we can call it directly from helper */

        $reminders = $this->_reminderFactory->create()->getCollection()->addFieldToFilter('reminder', 1);

        if (count($reminders)) {
            foreach ($reminders as $reminder) {
                $dateFrom = new \Zend_Date($reminder->getLasttimeSend(), 'yyyy-MM-dd HH:m:s');
                $dateTo = new \Zend_Date(null, 'yyyy-MM-dd HH:m:s');
                $dateTo->now();
                $dateTo->sub($dateFrom);
                $hoursLoad = $this->getInterVarByReminder($reminder);
                $diff = round($dateTo->getTimestamp() / $hoursLoad);

                if ($diff >= $reminder->getInterval()) {
                    if ($reminder->getCountSend() < $reminder->getCountNumber() || $reminder->getCountSend() == 0 || is_null($reminder->getCountSend())) {

                        $this->_emailHelper->reminderEmail(
                            $emailTempVariables,
                            $senderInfo,
                            $receiverInfo
                        );
                        $reminder->setCountNumber($reminder->getCountSend() + 1);
                        $reminder->setLasttimeSend($dateTo->now());
                        $reminder->save();
                    }
                }
                continue;
            }
        }
    }

    public function getStoreName()
    {
        return $this->scopeConfig->getValue(
            'general/store_information/name',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @param $reminder
     * @return int
     */
    public function getInterVarByReminder($reminder)
    {
        switch ($reminder->getReminderOption()) {
            case 'daily':
                return 24 * 60 * 60;
                break;
            case 'weekly':
                return (24 * 7 * 60 * 60);
                break;
            case 'monthly':
                echo "i equals 2";
                break;
            case 'hours':
                return 60 * 60;
                break;
        }
    }
}