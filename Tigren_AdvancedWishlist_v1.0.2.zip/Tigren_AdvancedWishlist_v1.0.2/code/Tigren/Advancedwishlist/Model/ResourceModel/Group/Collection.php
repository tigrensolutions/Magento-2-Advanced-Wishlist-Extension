<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model\ResourceModel\Group;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'tigren_wishlistplus_group_id';

    /**
     * Define resources model
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Tigren\WishlistPlus\Model\Group', 'Tigren\WishlistPlus\Model\ResourceModel\Group');
    }
}