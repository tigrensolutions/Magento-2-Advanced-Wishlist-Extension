<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model\ResourceModel\Reminder;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'tigren_wishlistplus_item_id';

    /**
     * Define resources model
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Tigren\WishlistPlus\Model\Reminder', 'Tigren\WishlistPlus\Model\ResourceModel\Reminder');
    }
}