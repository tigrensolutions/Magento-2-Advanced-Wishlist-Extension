<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Group extends AbstractDb
{
    public function getProductId($groupId)
    {
        $connection = $this->getConnection();
        $wishlistItemTable = $this->getTable('wishlist_item');
        $where = $connection->quoteInto('group_id = ?', $groupId);
        $sql = $connection->select()
            ->from($wishlistItemTable, array('product_id'))
            ->join('tigren_wishlistplus_item',
                'tigren_wishlistplus_item.tigren_wishlistplus_item_id = wishlist_item.wishlist_item_id',
                $cols = 'product_qty', $schema = null)
            ->where($where);
        $count = $connection->fetchPairs($sql);

        return $count;
    }

    /**
     *
     * @param $productId
     * @return string
     */
    public function getWishlistItemId($productId)
    {
        $connection = $this->getConnection();
        $table = $this->getTable('wishlist_item');
        $where = $connection->quoteInto("product_id = ?", $productId);
        $sql = $connection->select()->from($table, array('wishlist_item_id'))->where($where);
        $id = $connection->fetchCol($sql);

        return $id;
    }

    /**
     *
     * @param $productId
     * @return string
     */
    public function getQtyWishlistItemId($productId)
    {
        $connection = $this->getConnection();
        $table = $this->getTable('wishlist_item');
        $where = $connection->quoteInto("product_id = ? AND wishlist_item_id > 7", $productId);
        $sql = $connection->select()->from($table, array('qty'))->where($where);
        $id = $connection->fetchOne($sql);

        return $id;
    }

    /**
     * @param $group
     * @return array
     */
    public function getWishlistPlusItemId($group)
    {
        $connection = $this->getConnection();
        $table = $this->getTable('tigren_wishlistplus_item');
        $where = $connection->quoteInto("group_id = ?", $group);
        $sql = $connection->select()->from($table, array('tigren_wishlistplus_item_id'))->where($where);
        $id = $connection->fetchCol($sql);

        return $id;
    }

    /**
     * @return array
     */
    public function getGroupIdByWishlistItemId($wishlistItemId)
    {
        $connection = $this->getConnection();
        $table = $this->getTable('tigren_wishlistplus_item');
        $where = $connection->quoteInto("tigren_wishlistplus_item_id = ?", $wishlistItemId);
        $sql = $connection->select()->from($table, array('group_id'))->where($where);
        $id = $connection->fetchOne($sql);

        return $id;
    }

    public function getQtyCurrent($wishlistIdCurrent, $oldGroup)
    {
        $connection = $this->getConnection();
        $table = $this->getTable('tigren_wishlistplus_item');
        $sql = $connection->select()->from($table,
            array('product_qty'))->where('tigren_wishlistplus_item_id = ' . $wishlistIdCurrent . ' AND group_id = ' . $oldGroup);
        $id = $connection->fetchOne($sql);

        return $id;
    }

    /**
     * @param $group
     * @return array
     */
    public function getGroupsForCustomer($customerId)
    {
        $connection = $this->getConnection();
        $mbWishlistGroupTable = $this->getTable('tigren_wishlistplus_group');
        $where = $connection->quoteInto('customer_id = ?', $customerId);
        $sql = $connection->select()->from($mbWishlistGroupTable, array('COUNT(customer_id)'))->where($where);
        $count = $connection->fetchOne($sql);

        return $count;
    }

    /**
     * @param $id
     * @return string
     */
    public function getQtysInAllGroup($id)
    {
        $connection = $this->getConnection();
        $mbWishlistItemTable = $this->getTable('tigren_wishlistplus_item');

        /**
         * @var $id : wishlist_item_id
         */
        $where = $connection->quoteInto('tigren_wishlistplus_item_id = ?', $id);
        $sql = $connection->select()->from($mbWishlistItemTable, array('SUM(product_qty)'))->where($where);
        $count = $connection->fetchOne($sql);

        return $count;
    }

    /**
     * @param $groupId
     * @return array
     */
    public function getFromGroupId($groupId)
    {
        $connection = $this->getConnection();
        $refWishlistItemTable = $this->getTable('tigren_wishlistplus_item');
        $where = $connection->quoteInto('group_id = ?', $groupId);
        $sql = $connection->select()->from($refWishlistItemTable,
            array('tigren_wishlistplus_item_id', 'product_qty'))->where($where);
        $count = $connection->fetchAll($sql);

        return $count;
    }

    /**
     * @param $wishlistItemId
     * @return string
     */
    public function getQtyFromWishlistItem($wishlistItemId)
    {
        $connection = $this->getConnection();
        $refWishlistItemTable = $this->getTable('wishlist_item');
        $where = $connection->quoteInto('wishlist_item_id = ?', $wishlistItemId);
        $sql = $connection->select()->from($refWishlistItemTable, array('qty'))->where($where);
        $qty = $connection->fetchOne($sql);
        return $qty;
    }

    public function getItemsForDefaultGroup($customerId)
    {
        $connection = $this->getConnection();
        $wishlistTable = $this->getTable('wishlist');
        $wishlistItemTable = $this->getTable('wishlist_item');
        $mbWishlistItemTable = $this->getTable('tigren_wishlistplus_item');
        $mbWishlistGroupTable = $this->getTable('tigren_wishlistplus_group');

        $sql = $connection->select()
            ->from(
                array('wli' => $wishlistItemTable),
                array('wishlist_item_id', 'qty')
            )
            ->joinLeft(
                array('wl' => $wishlistTable),
                'wl.wishlist_id = wli.wishlist_id',
                array()
            )
            ->joinLeft(
                array('mwli' => $mbWishlistItemTable),
                'mwli.tigren_wishlistplus_item_id = wli.wishlist_item_id',
                array()
            )
            ->joinLeft(
                array('mwlg' => $mbWishlistGroupTable),
                'mwlg.customer_id = wl.customer_id',
                array()
            )
            ->where('mwli.tigren_wishlistplus_item_id IS NULL AND wl.customer_id = ' . $customerId);

        $items = $connection->fetchAll($sql);

        return $items;
    }

    protected function _construct()
    {
        $this->_init('tigren_wishlistplus_group', 'tigren_wishlistplus_group_id');
    }
}