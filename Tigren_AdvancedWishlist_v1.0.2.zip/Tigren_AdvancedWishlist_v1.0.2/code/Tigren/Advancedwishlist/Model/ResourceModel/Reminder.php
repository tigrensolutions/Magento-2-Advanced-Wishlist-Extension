<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Reminder extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('mb_wishlistplus_reminder', 'mb_wishlistplus_reminder_id');
    }
}