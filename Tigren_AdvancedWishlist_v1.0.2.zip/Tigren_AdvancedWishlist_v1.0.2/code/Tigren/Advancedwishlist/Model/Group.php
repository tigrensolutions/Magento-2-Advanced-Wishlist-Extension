<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model;

use Magento\Framework\Model\AbstractModel;

class Group extends AbstractModel
{
    /**
     * @param $wishlistIdCurrent
     * @param $productId
     * @param $groupId
     * @return $this
     */
    public function updateWishlistProduct($itemId, $qty)
    {
        $connection = $this->getResource()->getConnection();
        $table = $connection->getTableName('tigren_wishlistplus_item');
        $insert = ['tigren_wishlistplus_item_id' => $itemId, 'group_id' => $this->getId(), 'product_qty' => $qty];
        $connection->insertOnDuplicate($table, $insert,
            ['product_qty' => new \Zend_Db_Expr("`product_qty` + " . $qty)]);

        return $this;
    }

    /**
     * Return number of quantity in group
     *
     * @return mixed
     */
    public function getQtysInAllGroup($id)
    {
        return $this->getResource()->getQtysInAllGroup($id);
    }

    /**
     * @param $itemId
     * @param $qty
     * @return $this
     */
    public function updateWishlistProductFromUpdateGroup($itemId, $groupId, $qty)
    {
        $connection = $this->getResource()->getConnection();
        $table = $connection->getTableName('tigren_wishlistplus_item');
        $insert = ['tigren_wishlistplus_item_id' => $itemId, 'group_id' => $groupId, 'product_qty' => $qty];
        $connection->insertOnDuplicate($table, $insert,
            ['product_qty' => new \Zend_Db_Expr("`product_qty` + " . $qty)]);

        return $this;
    }

    /**
     * @param $itemId
     * @param $qty
     * @return $this
     */
    public function updateQtyGroupRemove($itemId, $groupId, $qty)
    {
        $connection = $this->getResource()->getConnection();
        $wishlistItemTable = $connection->getTableName('wishlist_item');
        $wishslistPlusItemTable = $connection->getTableName('tigren_wishlistplus_item');
        $connection->delete($wishslistPlusItemTable,
            'tigren_wishlistplus_item_id = ' . $itemId . ' AND group_id = ' . $groupId);
        $insert = ['wishlist_item_id' => $itemId, 'qty' => $qty];
        $connection->insertOnDuplicate($wishlistItemTable, $insert, ['qty' => new \Zend_Db_Expr("`qty` - " . $qty)]);

        return $this;
    }

    /**
     * @param $itemId
     * @param $qty
     * @return $this
     */
    public function updateQtyGroupEdit($itemId, $groupId, $qty)
    {
        $connection = $this->getResource()->getConnection();
        $wishslistPlusItemTable = $connection->getTableName('tigren_wishlistplus_item');
        $dataUpdate = [
            'product_qty' => $qty
        ];
        $connection->update($wishslistPlusItemTable, $dataUpdate,
            'group_id = ' . $groupId . ' AND tigren_wishlistplus_item_id = ' . $itemId);
        return $this;
    }

    public function getQtyFromWishlistItem($wishlistItemId)
    {
        return $this->getResource()->getQtyFromWishlistItem($wishlistItemId);
    }

    /**
     * @param $groupId
     * @return mixed
     */
    public function getFromGroupId($groupId)
    {
        return $this->getResource()->getFromGroupId($groupId);
    }

    /**
     * Update group when change group
     * Product in old group will be delete
     *
     * @param $itemId
     * @param $groupId
     * @return $this
     */
    public function deleteWishlistProductFromUpdateGroup($itemId, $groupId)
    {
        $connection = $this->getResource()->getConnection();
        $table = $connection->getTableName('tigren_wishlistplus_item');
        $connection->delete($table, 'tigren_wishlistplus_item_id = ' . $itemId . ' AND group_id = ' . $groupId);

        return $this;
    }

    /**
     *
     * Demo
     * @param $itemId
     * @param $qty
     * @return $this
     */
    public function updateWishlistProduct2($itemId, $qty)
    {
        $connection = $this->getResource()->getConnection();
        $table = $connection->getTableName('tigren_wishlistplus_item');
        $qtyCurrent = $this->getResource()->getQtyCurrent($itemId);
        $data = [
            'tigren_wishlistplus_item_id' => $itemId,
            'group_id' => $this->getId(),
            'product_qty' => $qtyCurrent + $qty
        ];
        $connection->insertOnDuplicate($table, $data, ['tigren_wishlistplus_item_id', 'product_qty']);

        return $this;
    }

    /**
     * get current qty in product
     *
     * @param $wishlistIdCurrent
     * @return mixed
     */
    public function getQtyCurrent($wishlistIdCurrent, $oldGroup)
    {
        return $this->getResource()->getQtyCurrent($wishlistIdCurrent, $oldGroup);
    }

    /**
     * @param $newGroupName
     * @param $groupId
     * @return $this
     */
    public function updateGroup($newGroupName, $groupId)
    {
        $connection = $this->getResource()->getConnection();
        $table = $connection->getTableName('tigren_wishlistplus_group');
        $sql = $connection->update($table, ['group_name' => $newGroupName],
            'tigren_wishlistplus_group_id = ' . $groupId);

        return $this;
    }

    /**
     * @param $wishlistItemId
     * @return array
     */
    public function getGroupByWishlistItemId($wishlistItemId)
    {
        $connection = $this->getResource()->getConnection();
        $tableWishlistItem = $connection->getTableName('tigren_wishlistplus_item');
        $where = $connection->quoteInto("tigren_wishlistplus_item_id = ?", $wishlistItemId);
        $sql = $connection->select()->from($tableWishlistItem, array('group_id'))->where($where);
        $id = $connection->fetchCol($sql);

        return $id;
    }

    public function isCreatedWishlistGroup($customerId)
    {
        $count = $this->getResource()->getGroupsForCustomer($customerId);

        if ($count) {
            return true;
        }

        return false;
    }

    public function getItemsForDefaultGroup($customerId)
    {
        $items = $this->getResource()->getItemsForDefaultGroup($customerId);

        $connection = $this->getResource()->getConnection();
        $table = $connection->getTableName('tigren_wishlistplus_item');
        foreach ($items as $item) {
            $insert = [
                'tigren_wishlistplus_item_id' => $item['wishlist_item_id'],
                'group_id' => $this->getId(),
                'product_qty' => $item['qty']
            ];
            $connection->insert($table, $insert);
        }

        return $this;
    }

    /**
     * Get wishlistitem in group
     *
     * @param $group
     * @return mixed
     */
    public function getWishlistPlusItemId($group)
    {
        return $this->getResource()->getWishlistPlusItemId($group);
    }

    /**
     * @param $wishlistItemId
     * @return array
     */
    public function changeGroupforWishlistItem($oldGroup, $newGroup, $wishlistItemId)
    {
        $connection = $this->getResource()->getConnection();
        $table = $connection->getTableName('tigren_wishlistplus_item');
        $where = $connection->quoteInto("tigren_wishlistplus_item_id = ?", $wishlistItemId);
        $sql = $connection->update($table, ['group_id' => $newGroup], $where);

        return $this;
    }

    public function getGroupIdByWishlistItemId($wishlistItemId)
    {
        $groupId = $this->getResource()->getGroupIdByWishlistItemId($wishlistItemId);
        return $groupId;
    }

    public function getProductId($groupId)
    {
        return $this->getResource()->getProductId($groupId);
    }

    public function insertGroupForConfigurableProduct($groupId, $wishlistItemId, $qty)
    {
        $connection = $this->getResource()->getConnection();
        $mbWishlistItemTable = $connection->getTableName('tigren_wishlistplus_item');

        $insert = [
            'tigren_wishlistplus_item_id' => $wishlistItemId,
            'group_id' => $groupId,
            'product_qty' => $qty
        ];
        $connection->insertOnDuplicate($mbWishlistItemTable, $insert, ['product_qty' => new \Zend_Db_Expr($qty)]);
    }

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Tigren\WishlistPlus\Model\ResourceModel\Group');
    }
}