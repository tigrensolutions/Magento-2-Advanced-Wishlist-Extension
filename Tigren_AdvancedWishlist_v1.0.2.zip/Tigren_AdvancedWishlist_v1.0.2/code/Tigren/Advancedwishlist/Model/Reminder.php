<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model;

use Magento\Framework\Model\AbstractModel;

class Reminder extends AbstractModel
{
    protected function _construct()
    {
        $this->_init('Tigren\WishlistPlus\Model\ResourceModel\Reminder');
    }
}