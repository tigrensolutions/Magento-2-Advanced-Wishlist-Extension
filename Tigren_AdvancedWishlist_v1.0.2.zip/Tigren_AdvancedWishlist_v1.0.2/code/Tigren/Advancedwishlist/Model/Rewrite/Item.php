<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model\Rewrite;

class Item extends \Magento\Wishlist\Model\Item
{
    public function getQtyInGroup($group)
    {
        $connection = $this->getResource()->getConnection();
        $tableWishlistItem = $connection->getTableName('tigren_wishlistplus_item');
        $sql = $connection->select()->from($tableWishlistItem,
            array('product_qty'))->where('group_id = ' . $group . ' AND tigren_wishlistplus_item_id = ' . $this->getId());
        $id = $connection->fetchOne($sql);
        return $id;
    }

}