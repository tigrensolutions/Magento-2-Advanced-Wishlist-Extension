<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Model\Rewrite;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Wishlist\Model\ItemFactory;
use Magento\Wishlist\Model\ResourceModel\Item\CollectionFactory;
use Magento\Wishlist\Model\ResourceModel\Wishlist as ResourceWishlist;
use Magento\Wishlist\Model\ResourceModel\Wishlist\Collection;
use Magento\Framework\App\ObjectManager;

class Wishlist extends \Magento\Wishlist\Model\Wishlist
{

    /**
     * @var \Tigren\WishlistPlus\Helper\Data
     */
    protected $_wishlistHelper;

    /**
     * @var Json
     */
    private $serializer;

    /**
     * Wishlist constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Catalog\Helper\Product $catalogProduct
     * @param \Magento\Wishlist\Helper\Data $wishlistData
     * @param ResourceWishlist $resource
     * @param Collection $resourceCollection
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     * @param ItemFactory $wishlistItemFactory
     * @param CollectionFactory $wishlistCollectionFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Framework\Math\Random $mathRandom
     * @param \Magento\Framework\Stdlib\DateTime $dateTime
     * @param ProductRepositoryInterface $productRepository
     * @param \Tigren\WishlistPlus\Helper\Data $wishlistHelper
     * @param bool $useCurrentWebsite
     * @param array $data
     * @param Json|null $serializer
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Helper\Product $catalogProduct,
        \Magento\Wishlist\Helper\Data $wishlistData,
        ResourceWishlist $resource,
        Collection $resourceCollection,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        ItemFactory $wishlistItemFactory,
        CollectionFactory $wishlistCollectionFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Framework\Math\Random $mathRandom,
        \Magento\Framework\Stdlib\DateTime $dateTime,
        ProductRepositoryInterface $productRepository,
        \Tigren\WishlistPlus\Helper\Data $wishlistHelper,
        $useCurrentWebsite = true,
        array $data = [],
        Json $serializer = null)
    {
        parent::__construct($context, $registry, $catalogProduct, $wishlistData, $resource, $resourceCollection, $storeManager, $date, $wishlistItemFactory, $wishlistCollectionFactory, $productFactory, $mathRandom, $dateTime, $productRepository, $useCurrentWebsite, $data, $serializer);
        $this->_wishlistHelper = $wishlistHelper;
        $this->serializer = $serializer ?: ObjectManager::getInstance()->get(Json::class);
    }

    /**
     * Adds new product to wishlist.
     * Returns new item or string on error.
     *
     * @param int|\Magento\Catalog\Model\Product $product
     * @param \Magento\Framework\DataObject|array|string|null $buyRequest
     * @param bool $forciblySetQty
     * @throws \Magento\Framework\Exception\LocalizedException
     * @return Item|string
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function addNewItem($product, $buyRequest = null, $forciblySetQty = false)
    {
        if($this->_wishlistHelper->isWishlistPlusEnable()) {
            /*
             * Always load product, to ensure:
             * a) we have new instance and do not interfere with other products in wishlist
             * b) product has full set of attributes
             */
            if ($product instanceof \Magento\Catalog\Model\Product) {
                $productId = $product->getId();
                // Maybe force some store by wishlist internal properties
                $storeId = $product->hasWishlistStoreId() ? $product->getWishlistStoreId() : $product->getStoreId();
            } else {
                $productId = (int)$product;
                if (isset($buyRequest) && $buyRequest->getStoreId()) {
                    $storeId = $buyRequest->getStoreId();
                } else {
                    $storeId = $this->_storeManager->getStore()->getId();
                }
            }

            try {
                $product = $this->productRepository->getById($productId, false, $storeId);
            } catch (NoSuchEntityException $e) {
                throw new \Magento\Framework\Exception\LocalizedException(__('Cannot specify product.'));
            }

            if ($buyRequest instanceof \Magento\Framework\DataObject) {
                $_buyRequest = $buyRequest;
            } elseif (is_string($buyRequest)) {
                $_buyRequest = new \Magento\Framework\DataObject(unserialize($buyRequest));
            } elseif (is_array($buyRequest)) {
                $_buyRequest = new \Magento\Framework\DataObject($buyRequest);
            } else {
                $_buyRequest = new \Magento\Framework\DataObject();
            }

            /* @var $product \Magento\Catalog\Model\Product */
            $cartCandidates = $product->getTypeInstance()->processConfiguration($_buyRequest, clone $product);

            /**
             * Error message
             */
            if (is_string($cartCandidates)) {
                return $cartCandidates;
            }

            /**
             * If prepare process return one object
             */
            if (!is_array($cartCandidates)) {
                $cartCandidates = [$cartCandidates];
            }

            $errors = [];
            $items = [];

            foreach ($cartCandidates as $candidate) {
                if ($candidate->getParentProductId()) {
                    continue;
                }
                $candidate->setWishlistStoreId($storeId);

                $qty = $candidate->getQty() ? $candidate->getQty() : 1;
                // No null values as qty. Convert zero to 1.
                $item = $this->_addCatalogProduct($candidate, $qty, $forciblySetQty);
                $items[] = $item;

                // Collect errors instead of throwing first one
                if ($item->getHasError()) {
                    $errors[] = $item->getMessage();
                }
            }

            if (!empty($this->_registry->registry('groupIdInUpdate'))) {
                $om = \Magento\Framework\App\ObjectManager::getInstance();
                $groupFactory = $om->get('Tigren\WishlistPlus\Model\GroupFactory')->create();
                $groupId = $this->_registry->registry('groupIdInUpdate');
                $wishlistItemId = $item->getId();
                $groupFactory->insertGroupForConfigurableProduct($groupId, $wishlistItemId, $qty);

            }

            $this->_eventManager->dispatch('wishlist_product_add_after', ['items' => $items]);

            return $item;
        }else{
            /*
         * Always load product, to ensure:
         * a) we have new instance and do not interfere with other products in wishlist
         * b) product has full set of attributes
         */
            if ($product instanceof \Magento\Catalog\Model\Product) {
                $productId = $product->getId();
                // Maybe force some store by wishlist internal properties
                $storeId = $product->hasWishlistStoreId() ? $product->getWishlistStoreId() : $product->getStoreId();
            } else {
                $productId = (int)$product;
                if (isset($buyRequest) && $buyRequest->getStoreId()) {
                    $storeId = $buyRequest->getStoreId();
                } else {
                    $storeId = $this->_storeManager->getStore()->getId();
                }
            }

            try {
                $product = $this->productRepository->getById($productId, false, $storeId);
            } catch (NoSuchEntityException $e) {
                throw new \Magento\Framework\Exception\LocalizedException(__('Cannot specify product.'));
            }

            if ($buyRequest instanceof \Magento\Framework\DataObject) {
                $_buyRequest = $buyRequest;
            } elseif (is_string($buyRequest)) {
                $isInvalidItemConfiguration = false;
                try {
                    $buyRequestData = $this->serializer->unserialize($buyRequest);
                    if (!is_array($buyRequestData)) {
                        $isInvalidItemConfiguration = true;
                    }
                } catch (\InvalidArgumentException $exception) {
                    $isInvalidItemConfiguration = true;
                }
                if ($isInvalidItemConfiguration) {
                    throw new \InvalidArgumentException('Invalid wishlist item configuration.');
                }
                $_buyRequest = new \Magento\Framework\DataObject($buyRequestData);
            } elseif (is_array($buyRequest)) {
                $_buyRequest = new \Magento\Framework\DataObject($buyRequest);
            } else {
                $_buyRequest = new \Magento\Framework\DataObject();
            }

            /* @var $product \Magento\Catalog\Model\Product */
            $cartCandidates = $product->getTypeInstance()->processConfiguration($_buyRequest, clone $product);

            /**
             * Error message
             */
            if (is_string($cartCandidates)) {
                return $cartCandidates;
            }

            /**
             * If prepare process return one object
             */
            if (!is_array($cartCandidates)) {
                $cartCandidates = [$cartCandidates];
            }

            $errors = [];
            $items = [];

            foreach ($cartCandidates as $candidate) {
                if ($candidate->getParentProductId()) {
                    continue;
                }
                $candidate->setWishlistStoreId($storeId);

                $qty = $candidate->getQty() ? $candidate->getQty() : 1;
                // No null values as qty. Convert zero to 1.
                $item = $this->_addCatalogProduct($candidate, $qty, $forciblySetQty);
                $items[] = $item;

                // Collect errors instead of throwing first one
                if ($item->getHasError()) {
                    $errors[] = $item->getMessage();
                }
            }

            $this->_eventManager->dispatch('wishlist_product_add_after', ['items' => $items]);

            return $item;
        }
    }
}