<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\WishlistPlus\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        $table = $installer->getConnection()
            ->newTable($installer->getTable('tigren_wishlistplus_group'))
            ->addColumn('tigren_wishlistplus_group_id', Table::TYPE_INTEGER, null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'Group Id')
            ->addColumn('group_name', Table::TYPE_TEXT, 255, ['nullable' => false, 'default' => ''], 'Title')
            ->addColumn('description', Table::TYPE_TEXT, 255, ['nullable' => false, 'default' => ''], 'Description')
            ->addColumn('color', Table::TYPE_TEXT, 255, ['nullable' => false, 'default' => ''], 'Color')
            ->addColumn('created_time', Table::TYPE_TIMESTAMP, null,
                ['nullable' => false, 'default' => Table::TIMESTAMP_INIT], 'WishlistPlus Creation Time')
            ->addColumn('updated_time', Table::TYPE_TIMESTAMP, null,
                ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE], 'WishlistPlus Update Time')
            ->addColumn('customer_id', Table::TYPE_INTEGER, null, ['unsigned' => true, 'nullable' => false],
                'Customer Id')
            ->addIndex(
                $installer->getIdxName('tigren_wishlistplus_group', ['description', 'created_time']),
                ['description', 'created_time'],
                [
                    'tigren_wishlistplus_group_id' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                ]
            )
            ->setComment('Tigren WishlistPlus Group');

        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
            ->newTable($installer->getTable('tigren_wishlistplus_item'))
            ->addColumn('tigren_wishlistplus_item_id', Table::TYPE_INTEGER, null,
                ['identity' => true, 'unique' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Product Id')
            ->addColumn('group_id', Table::TYPE_INTEGER, null,
                ['unsigned' => true, 'nullable' => false, 'primary' => true], 'Group ID')
            ->addColumn('product_qty', Table::TYPE_INTEGER, null, ['unsigned' => true, 'nullable' => false],
                'Qty Product')
            ->addForeignKey(
                $installer->getFkName('tigren_wishlistplus_item', 'group_id', 'tigren_wishlistplus_group',
                    'tigren_wishlistplus_group_id'),
                'group_id',
                $installer->getTable('tigren_wishlistplus_group'),
                'tigren_wishlistplus_group_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )
            ->addForeignKey(
                $installer->getFkName('tigren_wishlistplus_item', 'tigren_wishlistplus_item_id', 'wishlist_item',
                    'wishlist_item_id'),
                'tigren_wishlistplus_item_id',
                $installer->getTable('wishlist_item'),
                'wishlist_item_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )
            ->setComment('Tigren WishlistPlus Product');

        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
            ->newTable($installer->getTable('mb_wishlistplus_reminder'))
            ->addColumn('mb_wishlistplus_reminder_id', Table::TYPE_INTEGER, null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'Reminder Id')
            ->addColumn('customer_id', Table::TYPE_INTEGER, [], ['nullable' => true], 'Customer ID')
            ->addColumn('reminder', Table::TYPE_SMALLINT, [], ['nullable' => true], 'Reminder')
            ->addColumn('interval', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => ''], 'Interval')
            ->addColumn('reminder_option', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => ''],
                'Reminder Option')
            ->addColumn('count_number', Table::TYPE_SMALLINT, [], ['nullable' => true], 'Count Number')
            ->addColumn('count_send', Table::TYPE_SMALLINT, [], ['nullable' => true, 'default' => 0], 'Count Send')
            ->addColumn('lasttime_send', Table::TYPE_TIMESTAMP, null,
                ['nullable' => false, 'default' => Table::TIMESTAMP_INIT], 'Last time send')
            ->setComment('Tigren WishlistPlus Reminder');
        $installer->getConnection()->createTable($table);

        // end setup
        $installer->endSetup();
    }
}
